(function (root, factory) {
  if (typeof module === 'object' && module.exports) { module.exports = factory(); }
  else { root.JaduTVCore = factory(); }
}(this, function () {
  'use strict';
  var VIDEO = /^[A-Za-z0-9_-]{11}$/;
  var LIST = /^[A-Za-z0-9_-]{10,150}$/;
  function clean(value, max) { return typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max || 200) : ''; }
  function parameter(query, name) {
    var pairs = query.replace(/^\?/, '').split('&');
    var i, parts;
    for (i = 0; i < pairs.length; i += 1) {
      parts = pairs[i].split('=');
      if (parts[0] === name) { try { return decodeURIComponent(parts.slice(1).join('=').replace(/\+/g, ' ')); } catch (error) { return ''; } }
    }
    return '';
  }
  // Adapted from the stable phone release: strict hosts, canonical URLs, list precedence.
  function parse(input) {
    if (typeof input !== 'string' || input.length > 4096 || /[\u0000-\u001f\u007f\\]/.test(input)) { return null; }
    var text = input.trim();
    if (/^(?:(?:www|m|music)\.)?youtube\.com\//i.test(text) || /^(?:www\.)?youtu\.be\//i.test(text)) { text = 'https://' + text; }
    var match = /^https?:\/\/([^\/?#]+)(\/[^?#]*)?(?:\?([^#]*))?(?:#.*)?$/i.exec(text);
    if (!match) { return null; }
    var host = match[1].toLowerCase(), path = match[2] || '/', query = match[3] || '';
    var video = '', list = parameter(query, 'list'), parts = path.split('/').filter(function (x) { return !!x; });
    if (list && !LIST.test(list)) { return null; }
    if (host === 'youtu.be' || host === 'www.youtu.be') {
      if (parts.length !== 1) { return null; } video = parts[0];
    } else if (/^(?:www\.|m\.|music\.)?youtube\.com$/.test(host)) {
      if (/^\/watch\/?$/.test(path)) { video = parameter(query, 'v'); }
      else if (/^\/playlist\/?$/.test(path)) { if (!list) { return null; } }
      else if (parts.length === 2 && /^(shorts|live|embed)$/.test(parts[0])) {
        if (parts[0] === 'embed' && parts[1] === 'videoseries') { if (!list) { return null; } }
        else { video = parts[1]; }
      } else { return null; }
    } else if (/^(?:www\.)?youtube-nocookie\.com$/.test(host) && parts.length === 2 && parts[0] === 'embed') {
      if (parts[1] === 'videoseries') { if (!list) { return null; } } else { video = parts[1]; }
    } else { return null; }
    if (video && !VIDEO.test(video)) { return null; }
    if (!video && !list) { return null; }
    var kind = list ? 'playlist' : 'video';
    return {
      id: kind + ':' + (list || video), kind: kind, videoId: video, listId: list,
      url: list ? (video ? 'https://www.youtube.com/watch?v=' + video + '&list=' + list : 'https://www.youtube.com/playlist?list=' + list) : 'https://www.youtube.com/watch?v=' + video,
      title: (list ? '재생목록 ' : '동영상 ') + (list || video)
    };
  }
  function normalize(value) {
    if (!value || typeof value !== 'object') { return null; }
    var track = parse(value.url);
    if (!track) { return null; }
    track.title = clean(value.title, 200) || track.title;
    return track;
  }
  function read(raw) {
    if (!raw) { return []; }
    if (raw.length > 600000) { throw new Error('저장 자료가 너무 큽니다.'); }
    var value = JSON.parse(raw), seen = {}, result = [], i, track;
    if (!value || value.version !== 1 || !Array.isArray(value.tracks) || value.tracks.length > 500) { throw new Error('저장 자료 형식을 확인해 주세요.'); }
    for (i = 0; i < value.tracks.length; i += 1) {
      track = normalize(value.tracks[i]);
      if (!track) { throw new Error('잘못된 YouTube 주소가 들어 있습니다.'); }
      if (!seen[track.id]) { result.push(track); seen[track.id] = true; }
    }
    return result;
  }
  function write(tracks) { return JSON.stringify({ version: 1, tracks: tracks }); }
  function filter(tracks, term) {
    var q = clean(term).toLowerCase();
    return tracks.filter(function (track) { return !q || (track.title + ' ' + track.url).toLowerCase().indexOf(q) !== -1; });
  }
  function neighbour(nodes, from, direction) {
    var best = null, score = Infinity, i, rect, dx, dy, forward, cross, overlap, candidateScore;
    var vertical = direction === 'up' || direction === 'down';
    for (i = 0; i < nodes.length; i += 1) {
      rect = nodes[i];
      if (rect.id === from.id) { continue; }
      dx = (rect.left + rect.right - from.left - from.right) / 2;
      dy = (rect.top + rect.bottom - from.top - from.bottom) / 2;
      forward = direction === 'left' ? -dx : direction === 'right' ? dx : direction === 'up' ? -dy : dy;
      if (forward <= 1) { continue; }
      cross = Math.abs(vertical ? dx : dy);
      overlap = vertical ? Math.min(rect.right, from.right) > Math.max(rect.left, from.left) : Math.min(rect.bottom, from.bottom) > Math.max(rect.top, from.top);
      candidateScore = forward + cross * (overlap ? 0.3 : 3) + (overlap ? 0 : 800);
      if (candidateScore < score) { best = rect.id; score = candidateScore; }
    }
    return best;
  }
  return { parse: parse, normalize: normalize, read: read, write: write, filter: filter, clean: clean, neighbour: neighbour };
}));
