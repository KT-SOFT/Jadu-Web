// 목차: 1. 화면 준비 상태 2. 시작 오류 안내
(function () {
  'use strict';
  window.jaduTV93Ready = false;
  function failed() {
    if (window.jaduTV93Ready) { return; }
    var label = document.getElementById('tv-start-status');
    if (label) { label.textContent = 'TV 시험93 · 화면 시작 오류'; }
  }
  window.addEventListener('error', failed, true);
  window.addEventListener('load', failed, false);
}());
