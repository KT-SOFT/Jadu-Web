// Contents: browser and DOM fallbacks -> dialog fallbacks -> title motion -> initialization -> full video and internal Back -> remote keys and focus.
(function(){
'use strict';if(!window.globalThis)window.globalThis=window;
if(!Object.hasOwn)Object.hasOwn=function(value,key){return Object.prototype.hasOwnProperty.call(value,key);};
if(!Array.prototype.at)Object.defineProperty(Array.prototype,'at',{configurable:true,writable:true,value:function(index){var n=Number(index)||0;n=n<0?Math.ceil(n):Math.floor(n);return this[n<0?this.length+n:n];}});
if(!Object.fromEntries)Object.fromEntries=function(rows){var out={};rows.forEach(function(r){out[r[0]]=r[1];});return out;};
if(!Promise.allSettled)Promise.allSettled=function(rows){return Promise.all(rows.map(function(p){return Promise.resolve(p).then(function(value){return {status:'fulfilled',value:value};},function(reason){return {status:'rejected',reason:reason};});}));};
if(!Element.prototype.replaceChildren)Object.defineProperty(Element.prototype,'replaceChildren',{configurable:true,writable:true,value:function(){
var fragment=document.createDocumentFragment();
fragment.append.apply(fragment,arguments);
while(this.firstChild)this.removeChild(this.firstChild);
this.appendChild(fragment);
}});
Array.prototype.forEach.call(document.querySelectorAll('dialog'),function(dialog){
if(dialog.showModal)return;
if(typeof dialog.open!=='boolean')Object.defineProperty(dialog,'open',{get:function(){return this.hasAttribute('open');}});
dialog.showModal=function(){document.body.appendChild(this);this.setAttribute('open','');var first=this.querySelector('button,input,select');if(first)first.focus();};
dialog.close=function(){this.removeAttribute('open');this.dispatchEvent(new Event('close'));};
});
function visible(el){if(!el||el.disabled||el.tabIndex<0)return false;var r=el.getBoundingClientRect(),style=getComputedStyle(el);return !!(r.width&&r.height&&style.visibility!=='hidden'&&style.display!=='none');}
var titleFrame=0;
function updatePlayingTitle(){
var row=document.querySelector('#tracks .track-row.is-playing'),active=row&&row.querySelector('.track-main strong'),jadu=document.getElementById('simple-jadu');
Array.prototype.forEach.call(document.querySelectorAll('#tracks .tv-title-scroll'),function(title){if(title!==active)title.classList.remove('tv-title-scroll');});
if(!active)return;
var content=active.querySelector('.tv-title-text');
if(!content){content=document.createElement('span');content.className='tv-title-text';content.textContent=active.textContent;active.replaceChildren(content);}
var distance=content.scrollWidth-active.clientWidth,move=distance>2&&jadu.classList.contains('is-listening');
active.classList.toggle('tv-title-scroll',move);
if(move){content.style.setProperty('--title-shift',-distance+'px');content.style.setProperty('--title-duration',Math.max(8,distance/30+4)+'s');}
}
function scheduleTitleMotion(){cancelAnimationFrame(titleFrame);titleFrame=requestAnimationFrame(updatePlayingTitle);}
window.addEventListener('jadu-ready',function(){
if(document.activeElement===document.body){var first=document.getElementById('show-search-mode');if(first)first.focus();}
var tracks=document.getElementById('tracks'),jadu=document.getElementById('simple-jadu');
new MutationObserver(scheduleTitleMotion).observe(tracks,{childList:true});
new MutationObserver(scheduleTitleMotion).observe(jadu,{attributes:true,attributeFilter:['class']});
window.addEventListener('resize',scheduleTitleMotion);scheduleTitleMotion();
var size=document.getElementById('tv-video-size');size.addEventListener('click',function(){setVideoExpanded(!document.body.classList.contains('tv-video-expanded'));});
try{if(!history.state||!history.state.jaduTv95Back)history.pushState(Object.assign({},history.state,{jaduTv95Back:true}),'',location.href);}catch(error){}
window.addEventListener('popstate',function(){tvBack();try{history.pushState(Object.assign({},history.state,{jaduTv95Back:true}),'',location.href);}catch(error){}});
['fullscreenchange','webkitfullscreenchange'].forEach(function(type){document.addEventListener(type,function(){if(!document.fullscreenElement&&!document.webkitFullscreenElement&&!document.webkitIsFullScreen&&document.body.classList.contains('tv-video-expanded'))setVideoExpanded(false);});});
});
function setVideoExpanded(expanded){
document.body.classList.toggle('tv-video-expanded',expanded);
var size=document.getElementById('tv-video-size');size.textContent=expanded?'원래 화면':'전체 화면';size.setAttribute('aria-label',size.textContent);
try{if(expanded){var enter=document.documentElement.requestFullscreen||document.documentElement.webkitRequestFullscreen||document.documentElement.webkitRequestFullScreen;if(enter){var entered=enter.call(document.documentElement);if(entered&&entered.catch)entered.catch(function(){});}}else if(document.fullscreenElement||document.webkitFullscreenElement||document.webkitIsFullScreen){var exit=document.exitFullscreen||document.webkitExitFullscreen||document.webkitCancelFullScreen;var exited=exit.call(document);if(exited&&exited.catch)exited.catch(function(){});}}catch(error){}
scheduleTitleMotion();
}
function tvBack(){
if(document.body.classList.contains('tv-video-expanded')){setVideoExpanded(false);return;}
var dialogs=document.querySelectorAll('dialog[open]'),dialog=dialogs.length?dialogs[dialogs.length-1]:null;
if(dialog){dialog.close();return;}
var menus=['search-recent-menu','music-category-menu'];
for(var i=0;i<menus.length;i++){var menu=document.getElementById(menus[i]);if(menu&&!menu.hidden){var opener=document.querySelector('[aria-controls="'+menus[i]+'"][aria-expanded="true"]');if(opener)opener.click();else menu.hidden=true;return;}}
var title=document.getElementById('list-heading'),back=document.getElementById('show-browse');
if(title&&/ - 이전\s*$/.test(title.textContent)){title.click();return;}
if(visible(back))back.click();
}
document.addEventListener('keydown',function(event){
if(event.defaultPrevented)return;
var code=event.keyCode||event.which,active=document.activeElement,dialogs=document.querySelectorAll('dialog[open]'),dialog=dialogs.length?dialogs[dialogs.length-1]:null;
if(code===461||code===27||code===166||event.key==='BrowserBack'||(code===8&&active&&!/^(INPUT|TEXTAREA)$/.test(active.tagName))){event.preventDefault();tvBack();return;}
var play=document.getElementById('play');
if(code===179||code===415||code===19||code===413){if(visible(play)){var paused=play.getAttribute('aria-label')==='재생';if(code===179||(code===415&&paused)||((code===19||code===413)&&!paused))play.click();}event.preventDefault();return;}
if(code===13&&active&&active.type==='checkbox'){event.preventDefault();active.click();return;}
if(code<37||code>40||event.altKey||event.ctrlKey||event.metaKey)return;
if(active&&active.tagName==='SELECT')return;
if(active&&/^(INPUT|TEXTAREA)$/.test(active.tagName)&&active.type!=='checkbox'&&(code===37||code===39))return;
var origin=active&&active!==document.body?active.getBoundingClientRect():null,best=null,score=Infinity,root=dialog||document;
Array.prototype.forEach.call(root.querySelectorAll('button,input,select,a[href],[tabindex="0"]'),function(el){
if(el===active||!visible(el))return;var r=el.getBoundingClientRect();
if(!origin||!origin.width){if(!best)best=el;return;}
var dx=(r.left+r.right-origin.left-origin.right)/2,dy=(r.top+r.bottom-origin.top-origin.bottom)/2;
if((code===37&&dx>=-1)||(code===39&&dx<=1)||(code===38&&dy>=-1)||(code===40&&dy<=1))return;
var forward=(code===37||code===39)?Math.abs(dx):Math.abs(dy),side=(code===37||code===39)?Math.abs(dy):Math.abs(dx),value=forward+side*3;
if(value<score){score=value;best=el;}
});if(best){event.preventDefault();best.focus();}
});
}());
