// Contents: stored lists -> controls and viewport fit -> search and queue -> YouTube playback -> account bridge -> remote keys and startup.
(function () {
  'use strict';
  var C = window.JaduTVCore, KEY = 'jadu-tv94-library-v1';
  var ENDPOINT = location.hostname === 'kt-soft.github.io' ? 'https://jadu-music-search-20261105.kangjae17.chatgpt.site/api/search' : 'api/search';
  var ACCOUNT_BASE = location.hostname === 'kt-soft.github.io' ? 'https://jadu-tv-account-20261105.kangjae17.chatgpt.site' : '';
  var accountSession = '', ACCOUNT_SESSION_KEY = 'jadu-tv94-page-session:' + ACCOUNT_BASE;
  var saved = [], results = [], browseTracks = [], queue = [], current = null, selected = null;
  var RECENT_QUERY_KEY = 'jadu-tv94-recent-queries-v1';
  var recentQueries = [], queryMenuOpener = null;
  var accountListKind = '', collectionItems = null, savedLimit = 20;
  var accountStatusTicket = 0;
  var pages = null, queuePages = null, moreRequest = null;
  var tab = 'results', filter = '', readError = false, deleted = null, panelFocus = null;
  var listVisible = true, videoVisible = true, cinema = false, playerView = false;
  var lastListFocus = '', listTrail = [], listKey = '', historyBusy = false, historyHandling = false;
  var player = null, frame = null, apiReady = false, playerReady = false, playing = false, wantsPlay = false;
  var generation = 0, requestId = 0, homeRequestId = 0, request = null, homeRequest = null, lastSearch = '', lastCategory = 'all';
  var WATCHED_KEY = 'jadu-tv94-watched-v1', watched = [], historyReadError = false, recordedId = '';
  var categoryQueries = { all:'인기 동영상', news:'오늘 뉴스', podcasts:'한국 팟캐스트', music:'한국 인기 가요', mixes:'음악 믹스' };
  var categoryLabels = { recommendations:'자두 추천', feed:'구독영상', library:'보관함', all:'전체', news:'뉴스', podcasts:'팟캐스트', music:'음악', mixes:'믹스', watched:'감상한 동영상' };
  var petHidden = false, petSound = true, petAudio = null, composing = false, playTimer = null;
  var fitTimer = null, displayReportTimer = null, fullscreenNative = false;
  var seekDragging = false, captionsPreferred = false, resumePlayback = null;
  var accountState = { connected:false }, accountTimer = null, accountEpoch = 0;
  var PLAYBACK_KEY = 'jadu-tv94-playback-v1', RETURN_KEY = 'jadu-tv94-return-v1';
  var officialPlayback = false;
  var FIT_KEY = 'jadu-tv94-fixed-fit-v1', fixedFit = /web0s|webos|netcast|smart.?tv/i.test(navigator.userAgent);
  function $(id) { return document.getElementById(id); }
  function text(el, value) { el.textContent = value; }
  function status(value) { text($('status'), value); }
  function node(tag, value, className) { var n = document.createElement(tag); if (typeof value === 'string') { text(n, value); } if (className) { n.className = className; } return n; }
  function button(label, fn, cls) { var b = node('button', label, cls); b.type = 'button'; b.setAttribute('data-nav', ''); b.addEventListener('click', fn); return b; }
  function focus(el) { if (!el || el.disabled) { return; } el.focus(); if (el.hasAttribute('data-track') || el.hasAttribute('data-card')) { var region = el.hasAttribute('data-card') ? $('browse-panel') : $('list-panel'), r = el.getBoundingClientRect(), p = region.getBoundingClientRect(); if (r.bottom > p.bottom) { region.scrollTop += r.bottom - p.bottom + 5; } if (r.top < p.top) { region.scrollTop -= p.top - r.top + 5; } } }
  function track(value) { var t = C.normalize(value); if (t) { t.author = C.clean(value.author, 160); } return t; }
  function normalizeList(items) { var seen = {}, out = []; (Array.isArray(items) ? items : []).slice(0, 500).forEach(function (item) { var t = track(item); if (t && !seen[t.id]) { out.push(t); seen[t.id] = true; } }); return out; }
  function readStorage() { try { saved = C.read(localStorage.getItem(KEY)); } catch (e) { readError = true; status('기존 저장 자료를 읽지 못했습니다. 자료를 보호하기 위해 저장을 잠시 막았습니다.'); } }
  function persist(items) { if (readError) { status('기존 저장 자료를 읽지 못해 덮어쓰지 않습니다.'); return false; } try { var value = C.write(items); localStorage.setItem(KEY, value); if (localStorage.getItem(KEY) !== value) { throw new Error('readback'); } saved = items; text($('storage'), '저장됨'); return true; } catch (e) { status('이 브라우저에 저장하지 못했습니다. 기존 목록은 유지합니다.'); return false; } }
  function visibleTracks() { return tab === 'results' ? results : C.filter(saved, filter); }
  function appendTrackRow(item, index) {
    var row = node('div', '', 'track' + (selected && selected.id === item.id ? ' current' : ''));
    row.setAttribute('role', 'listitem');
    var control = button('', function () {
      selected = item;
      queue = visibleTracks().slice();
      queuePages = tab === 'results' ? pages : null;
      startTrack(item);
    }, 'track-main');
    control.setAttribute('data-track', item.id);
    control.setAttribute('aria-label', item.title + ' 재생');
    control.appendChild(node('strong', item.title + (item.author ? ' · ' + item.author : '')));
    row.appendChild(control);
    $('tracks').appendChild(row);
    return control;
  }
  function renderList() {
    var active = document.activeElement, restore = active && active.getAttribute('data-track'), visible = visibleTracks(), restored = null;
    $('tracks').innerHTML = ''; text($('count'), saved.length ? String(saved.length) : ''); text($('result-count'), results.length ? String(results.length) : '');
    $('show-results').setAttribute('aria-selected', String(tab === 'results')); $('show-saved').setAttribute('aria-selected', String(tab === 'saved'));
    $('saved-filter-row').hidden = tab !== 'saved' || saved.length === 0;
    $('empty-list').hidden = visible.length > 0;
    text($('empty-list'), tab === 'results' ? (lastSearch ? '검색 결과가 없습니다.' : '노래 제목이나 가수를 검색해 주세요.') : (filter ? '일치하는 저장곡이 없습니다.' : '저장된 노래가 없습니다.'));
    (tab === 'saved' ? visible.slice(0,savedLimit) : visible).forEach(function (item, index) {
      var control = appendTrackRow(item, index);
      if (restore === item.id) { restored = control; }
    });
    if (restored) { focus(restored); }
    syncMoreButtons();
    controls();
  }
  function controls() {
    text($('play'), playing ? '일시정지 Ⅱ' : '재생 ▶');
    var chosen = selected || current, stored = chosen && saved.some(function (t) { return t.id === chosen.id; });
    $('save').disabled = !chosen || readError; $('delete').disabled = !stored || readError;
    $('play').disabled = !current; $('pause').disabled = !current || officialPlayback;
    $('fullscreen').disabled = officialPlayback;
    $('previous').disabled = !current || (current.kind !== 'playlist' && queue.length < 2) || (officialPlayback && current.kind === 'playlist'); $('next').disabled = $('previous').disabled;
    $('return-player').hidden = !current || officialPlayback; text($('current-title'), current ? current.title : '재생 대기');
    if (current) { text($('video-title'), current.title); }
  }
  function applyViews() {
    if (!listVisible && !videoVisible) { listVisible = true; }
    $('tv-shell').className = 'tv-shell' + (!listVisible ? ' list-hidden' : '') + (!videoVisible ? ' video-hidden' : '') + (cinema ? ' cinema' : '') + (playerView ? ' playing-view' : '');
    $('toggle-list').checked = listVisible && !cinema; $('toggle-video').checked = videoVisible;
    text($('fullscreen'), cinema ? '전체화면 끝' : '전체화면');
    $('player-panel').hidden = !playerView; $('browse-panel').hidden = playerView;
    $('video-mount').hidden = !playerView || !videoVisible;
    layoutPlayerControls(); syncPlayerHistory(); scheduleFit(); reportDisplay();
  }
  // Old TV engines do not reliably resolve nested flex/percentage iframe heights.
  // Size the player against the visible viewport and reserve space for its controls.
  // Temporary LAN-only display diagnostics. No song, account or saved-list data.
  function reportDisplay() {
    if (location.port !== '8840') { return; }
    clearTimeout(displayReportTimer); displayReportTimer = setTimeout(function () {
      try {
        var ids = ['tv-shell','video-column','player-panel','player-controls','video-stage','video-mount','yt-frame','library','list-panel','status'];
        var elements = [], i, el, r, cs;
        for (i = 0; i < ids.length; i += 1) {
          el = $(ids[i]); if (!el) { continue; } r = el.getBoundingClientRect(); cs = window.getComputedStyle(el);
          elements.push({id:ids[i],x:Math.round(r.left),y:Math.round(r.top),w:Math.round(r.width),h:Math.round(r.height),bottom:Math.round(r.bottom),scrollHeight:el.scrollHeight,clientHeight:el.clientHeight,display:cs.display,overflow:cs.overflow,position:cs.position});
        }
        var xhr = new XMLHttpRequest(); xhr.open('POST','api/display-check',true); xhr.setRequestHeader('Content-Type','application/json');
        xhr.send(JSON.stringify({version:'0.3.19-' + (fixedFit ? 'px' : 'auto'),viewport:[window.innerWidth,window.innerHeight],client:[document.documentElement.clientWidth,document.documentElement.clientHeight],screen:[screen.width,screen.height],dpr:window.devicePixelRatio||1,scroll:[window.pageXOffset||0,window.pageYOffset||0],view:{playing:playerView,cinema:cinema,list:listVisible,video:videoVisible,ready:playerReady,results:results.length},elements:elements}));
      } catch (ignore) {}
    }, 400);
  }
  function scheduleFit() { clearTimeout(fitTimer); fitTimer = setTimeout(fitPlayer, 0); }
  function pixelStyle(el, name, value) { var css = value + 'px'; if (el.style[name] !== css) { el.style[name] = css; } }
  function sizeFrame(width, height) {
    if (!frame) { return; }
    if (frame.getAttribute('width') !== String(width)) { frame.setAttribute('width', String(width)); }
    if (frame.getAttribute('height') !== String(height)) { frame.setAttribute('height', String(height)); }
    pixelStyle(frame, 'width', width); pixelStyle(frame, 'height', height);
  }
  // Older Chromium does not propagate CSS zoom into the embedded document.
  // Give the TV one screen-space rectangle, with no scaled parent coordinates.
  function layoutFrame(width, height) {
    if (!frame || width <= 0 || height <= 0) { return; }
    var w = width, h = height, left = 0, top = 0;
    if (fixedFit) {
      var units = Math.floor(Math.min(width / 16, height / 9));
      if (units >= 23) { w = units * 16; h = units * 9; }
      var box = $('video-mount').getBoundingClientRect();
      left = Math.round(box.left + (width - w) / 2);
      top = Math.round(box.top + (height - h) / 2);
    }
    frame.style.position = fixedFit ? 'fixed' : 'absolute';
    pixelStyle(frame, 'left', left); pixelStyle(frame, 'top', top);
    sizeFrame(w, h);
  }
  function syncFitControl() {
    var control = $('fixed-fit');
    control.disabled = officialPlayback;
    control.setAttribute('aria-pressed', String(fixedFit && !officialPlayback));
    text($('fit-state'), officialPlayback ? '자두 전용' : (fixedFit ? '켜짐' : '꺼짐'));
    control.title = officialPlayback ? 'YouTube에서 재생을 끄면 자두 안에서 사용할 수 있습니다.' : '자두 안에서 영상과 재생바를 함께 16:9로 맞춥니다.';
  }
  function readFitPreference() {
    try { var pref = JSON.parse(localStorage.getItem(FIT_KEY)); if (pref && typeof pref.enabled === 'boolean') { fixedFit = pref.enabled; } } catch (ignore) {}
    syncFitControl();
  }
  function changeFitPreference() {
    if (officialPlayback) { return; }
    fixedFit = !fixedFit; syncFitControl();
    try { localStorage.setItem(FIT_KEY, JSON.stringify({enabled:fixedFit})); } catch (ignore) {}
    fitPlayer(); reportDisplay();
    status(fixedFit ? '영상 영역의 실제 크기에 16:9로 맞췄습니다.' : '기본 크기로 돌아왔습니다.');
  }
  function fitPlayer() {
    var shell = $('tv-shell'), width = window.innerWidth || document.documentElement.clientWidth;
    var height = window.innerHeight || document.documentElement.clientHeight;
    if (width > 680) { pixelStyle(shell, 'height', height); } else if (shell.style.height) { shell.style.height = ''; }
    if (!playerView || !videoVisible || !$('video-column').offsetWidth) { return; }
    var panel = $('player-panel'), stage = $('video-stage'), mount = $('video-mount');
    if (cinema) {
      var toolbarHeight = $('player-controls').offsetHeight;
      pixelStyle(mount, 'left', 0); pixelStyle(mount, 'top', 0);
      pixelStyle(mount, 'width', width); pixelStyle(mount, 'height', Math.max(200,height - toolbarHeight));
      layoutFrame(width, Math.max(200,height - toolbarHeight));
      reportDisplay(); return;
    }
    var bottom = width > 680 ? shell.getBoundingClientRect().bottom - (parseFloat(window.getComputedStyle(shell).paddingBottom) || 0) : $('video-column').getBoundingClientRect().bottom;
    var room = Math.max(200, Math.floor(bottom - panel.getBoundingClientRect().top)), used = 0, i, child, style;
    pixelStyle(panel, 'height', room);
    for (i = 0; i < panel.children.length; i += 1) {
      child = panel.children[i]; if (child === stage || !child.offsetHeight) { continue; }
      style = window.getComputedStyle(child);
      used += child.offsetHeight + (parseFloat(style.marginTop) || 0) + (parseFloat(style.marginBottom) || 0);
    }
    var stageHeight = Math.max(200, Math.floor(room - used - 2));
    pixelStyle(stage, 'height', stageHeight);
    var frameWidth = Math.floor(Math.min(stage.clientWidth, stageHeight * 16 / 9));
    var frameHeight = Math.floor(frameWidth * 9 / 16);
    // Keep YouTube's required 200px minimum even on short windows; allow scrolling then.
    if (frameHeight < 200) { frameHeight = 200; }
    pixelStyle(mount, 'width', frameWidth); pixelStyle(mount, 'height', frameHeight);
    var stageRect = stage.getBoundingClientRect();
    pixelStyle(mount, 'left', Math.round(stageRect.left + (stage.clientWidth - frameWidth) / 2));
    pixelStyle(mount, 'top', Math.round(stageRect.top + Math.max(0, (stageHeight - frameHeight) / 2)));
    layoutFrame(frameWidth, frameHeight);
    reportDisplay();
  }
  function closePanel() { stopAccountPoll(); $('inline-panel').hidden = true; if (panelFocus && document.documentElement.contains(panelFocus) && !panelFocus.disabled) { focus(panelFocus); } panelFocus = null; }
  function openPanel(title) { stopAccountPoll(); panelFocus = document.activeElement; listVisible = true; if (cinema) { exitFullscreen(); } applyViews(); text($('inline-title'), title); $('inline-body').innerHTML = ''; $('inline-actions').innerHTML = ''; $('inline-panel').hidden = false; focus($('inline-close')); return $('inline-body'); }
  function action(label, fn, cls) { $('inline-actions').appendChild(button(label, fn, cls)); }
  function saveTrack() {
    var chosen = track(selected || current); if (!chosen) { return; }
    var exists = saved.some(function (t) { return t.id === chosen.id; }); if (!exists && saved.length >= 500) { status('최대 500곡까지 저장할 수 있습니다.'); return; }
    var body = openPanel(exists ? '저장한 노래 이름' : '노래 저장'); var label = node('label', '노래 이름'); label.htmlFor = 'save-title'; body.appendChild(label);
    var input = node('input'); input.id = 'save-title'; input.value = chosen.title; input.maxLength = 200; input.readOnly = true; input.setAttribute('data-nav', ''); body.appendChild(input);
    action('취소', closePanel); action('저장', function () { chosen.title = C.clean(input.value, 200) || chosen.title; var next = saved.slice(), found = false; next = next.map(function (t) { if (t.id === chosen.id) { found = true; return chosen; } return t; }); if (!found) { next.push(chosen); } if (persist(next)) { if (current && current.id === chosen.id) { current.title = chosen.title; } selected = chosen; closePanel(); renderList(); status('이 브라우저의 저장 목록에 넣었습니다.'); } }, 'primary'); focus(input);
  }
  function deleteTrack() { var chosen = selected || current, index = -1; if (!chosen) { return; } saved.forEach(function (t, i) { if (t.id === chosen.id) { index = i; } }); if (index < 0) { return; } var next = saved.slice(), removed = next.splice(index, 1)[0]; if (persist(next)) { deleted = { track: removed, index: index }; $('undo-delete').hidden = false; renderList(); status('저장 목록에서 삭제했습니다.'); } }
  function undoDelete() { if (!deleted) { return; } var next = saved.slice(); if (!next.some(function (t) { return t.id === deleted.track.id; })) { next.splice(Math.min(deleted.index, next.length), 0, deleted.track); } if (persist(next)) { deleted = null; $('undo-delete').hidden = true; renderList(); status('삭제한 곡을 복원했습니다.'); } }
  function fetchTracks(query, done, cursor) {
    var xhr = new XMLHttpRequest(), finished = false;
    var url = ENDPOINT + '?q=' + encodeURIComponent(query) + '&limit=20';
    if (cursor) { url += '&cursor=' + encodeURIComponent(cursor); }
    function finish(error, items, next, code) {
      if (finished) { return; }
      finished = true;
      done(error, items, next, code);
    }
    xhr.open('GET', url, true);
    xhr.timeout = 22000;
    xhr.onload = function () {
      if (xhr.status !== 200) {
        finish('검색 연결을 확인해 주세요. 다시 시도할 수 있습니다.', null, '', xhr.status);
        return;
      }
      var data, items;
      try {
        data = JSON.parse(xhr.responseText);
        if (data.available !== true || !Array.isArray(data.tracks)) { throw new Error('format'); }
        items = normalizeList(data.tracks).slice(0, 20);
      } catch (err) {
        finish('검색 결과를 읽지 못했습니다. 다시 시도해 주세요.');
        return;
      }
      finish(null, items, validCursor(data.nextCursor));
    };
    xhr.onerror = function () { finish('검색 서비스에 연결하지 못했습니다.'); };
    xhr.ontimeout = function () { finish('검색 응답이 늦습니다. 다시 시도해 주세요.'); };
    xhr.send();
    return xhr;
  }
  function validCursor(value) {
    return typeof value === 'string' && /^[a-f0-9]{24}\.[1-9]\d{0,2}$/.test(value) ? value : '';
  }
  function resetPaging() {
    var pending = moreRequest;
    moreRequest = null;
    pages = null;
    queuePages = null;
    if (pending) { pending.abort(); }
    syncMoreButtons();
  }
  function accountCursor(value) {
    return typeof value === 'string' && value.length <= 10000 && /^v1\.[A-Za-z0-9+/=]+\.[A-Za-z0-9+/=]+$/.test(value) ? value : '';
  }
  function validAccountRoute(route) {
    return typeof route === 'string' && /^(?:recommendations|subscription-feed|playlists|subscriptions|videos\?id=[A-Za-z0-9_-]{10,150}&kind=(?:channel|playlist))$/.test(route);
  }
  function beginPages(query, title, cursor, category, route, local) {
    pages = cursor ? {query:query, title:title, cursor:cursor, category:category || '', route:route || '', local:local || null, busy:false, failed:false, expired:false} : null;
    syncMoreButtons();
  }
  function showLocalItems(items, title, category, kind) {
    var snapshot = items.slice();
    renderCards(snapshot.slice(0,20),title,kind);
    beginPages('',title,snapshot.length > 20 ? '20' : '',category,'',snapshot);
  }
  function loadSavedPage() {
    var visible = visibleTracks(), first = null, stop = Math.min(savedLimit + 20,visible.length);
    for (var i = savedLimit; i < stop; i += 1) {
      var row = appendTrackRow(visible[i],i);
      if (!first) { first = row; }
    }
    savedLimit = stop;
    syncMoreButtons();
    if (first) { focus(first); }
  }
  function syncMoreButtons() {
    ['browse-more','list-more'].forEach(function (id) {
      var control = $(id), localSaved = id === 'list-more' && tab === 'saved';
      var available = localSaved ? visibleTracks().length > savedLimit : !!(pages && pages.cursor && (id === 'browse-more' || !collectionItems));
      var busy = available && !localSaved && pages.busy;
      control.hidden = !available;
      control.setAttribute('aria-busy',String(!!busy));
      control.setAttribute('aria-disabled',String(!!busy));
      text(control, busy ? '불러오는 중…' : !localSaved && pages && pages.expired ? '처음부터 다시 불러오기' : !localSaved && pages && pages.failed ? '더보기 다시 시도' : '더보기');
    });
  }
  function accountTracks(data, category) {
    var items = normalizeList(data.tracks);
    if (category !== 'recommendations') { return items; }
    var known = {};
    saved.forEach(function (item) { known[item.id] = true; });
    return items.filter(function (item) { return !known[item.id]; });
  }
  function nextPage(feed, done) {
    if (feed.local) {
      var start = Number(feed.cursor), end = start + 20;
      done(null,feed.local.slice(start,end),end < feed.local.length ? String(end) : '');
      return null;
    }
    if (!feed.route) { return fetchTracks(feed.query,done,feed.cursor); }
    var url = feed.route + (feed.route.indexOf('?') < 0 ? '?' : '&') + 'cursor=' + encodeURIComponent(feed.cursor);
    return accountRequest(url,'GET',function (error,data,code) {
      done(error,error ? [] : collectionItems ? data.collections || [] : accountTracks(data,feed.category),error ? '' : accountCursor(data.nextCursor),code);
    });
  }
  function loadMore(event) {
    var source = event.currentTarget, feed = pages;
    if (source === $('list-more') && tab === 'saved') { loadSavedPage(); return; }
    if (!feed || !feed.cursor || feed.busy) { return; }
    if (feed.expired) {
      if (collectionItems) { loadAccountCollections(feed.route,feed.title); }
      else if (feed.route.indexOf('videos?') === 0) { loadAccountVideoRoute(feed.route,feed.title); }
      else if (feed.category) { loadHome(feed.category); } else { search(feed.query); }
      return;
    }
    feed.busy = true;
    syncMoreButtons();
    moreRequest = nextPage(feed,function (error, items, next, code) {
      if (feed !== pages) { return; }
      moreRequest = null;
      feed.busy = false;
      if (error) {
        feed.failed = true; feed.expired = code === 410;
        syncMoreButtons(); status(error); return;
      }
      var known = {}, firstCard = null, firstRow = null, count = 0;
      var moveFocus = document.activeElement === source, list = collectionItems || browseTracks;
      list.forEach(function (item) { known['$' + item.id] = true; });
      items.forEach(function (item) {
        if (!item || !item.id || known['$' + item.id]) { return; }
        known['$' + item.id] = true;
        list.push(item);
        var card = collectionItems ? appendCollection(item) : appendCard(item);
        if (!firstCard) { firstCard = card; }
        if (!collectionItems) {
          results.push(item);
          if (tab === 'results') {
            var row = appendTrackRow(item,results.length - 1);
            if (!firstRow) { firstRow = row; }
          }
        }
        count += 1;
      });
      if (!collectionItems && queuePages === feed) { queue = results.slice(); }
      feed.failed = false;
      feed.cursor = next !== feed.cursor ? next : '';
      if (list.length) { $('home-message').hidden = true; if (!collectionItems && tab === 'results') { $('empty-list').hidden = true; } }
      text($('result-count'), results.length ? String(results.length) : '');
      text($('browse-title'), feed.title + ' · ' + list.length + '개');
      syncMoreButtons(); controls();
      status(count ? count + '개를 더 불러왔습니다. 총 ' + list.length + '개' : feed.cursor ? '이 페이지에는 새 항목이 없습니다. 다음 페이지를 더 볼 수 있습니다.' : '마지막 항목까지 보았습니다.');
      if (moveFocus) {
        var target = source === $('list-more') ? firstRow : firstCard;
        if (target) { focus(target); }
        else if (source.hidden) {
          var buttons = (source === $('list-more') ? $('tracks') : $('cards')).querySelectorAll('button');
          focus(buttons[buttons.length - 1] || $('query'));
        }
      }
      reportDisplay();
    });
  }

  function appendCard(item) {
    var card = node('div', '', 'music-card');
    card.setAttribute('role', 'listitem');
    var control = button('', function () {
      tab = 'results';
      listVisible = true;
      queue = browseTracks.slice();
      queuePages = pages;
      selected = item;
      lastListFocus = item.id;
      startTrack(item);
      if (!officialPlayback && videoVisible) { focus($('player-label')); }
    });
    control.setAttribute('data-card', item.id);
    control.setAttribute('aria-label', item.title + ' 재생');
    var image = node('img');
    image.alt = '';
    image.src = item.videoId ? 'https://i.ytimg.com/vi/' + item.videoId + '/mqdefault.jpg' : 'assets/icon.png';
    image.setAttribute('referrerpolicy', 'no-referrer');
    control.appendChild(image);
    control.appendChild(node('strong', item.title));
    control.appendChild(node('small', item.author || 'YouTube'));
    card.appendChild(control);
    $('cards').appendChild(card);
    return control;
  }
  function renderCards(items, title, kind) {
    collectionItems = null;
    accountListKind = kind || '';
    var label = '검색 결과';
    if (kind === 'watched') { label = '감상한 동영상'; }
    if (kind === 'feed') { label = '구독영상'; }
    if (kind === 'library') { label = '이 TV에 저장한 곡'; }
    if (kind === 'recommendations') { label = '자두 추천'; }
    text($('result-label'), label);
    browseTracks = items;
    results = items.slice();
    if (tab === 'results') { renderList(); }
    text($('browse-title'), title + ' · ' + items.length + '개');
    $('cards').innerHTML = '';
    $('home-message').hidden = items.length > 0;
    text($('home-message'), '동영상 목록이 없습니다. 다른 제목으로 검색해 주세요.');
    $('home-retry').hidden = true;
    items.forEach(appendCard);
  }
  function readRecentQueries() {
    var items = [], seen = {};
    try {
      var stored = JSON.parse(localStorage.getItem(RECENT_QUERY_KEY) || '[]');
      if (!Array.isArray(stored)) { return items; }
      stored.slice(0, 20).forEach(function (value) {
        var term = C.clean(value, 200), key = '$' + term.toLowerCase();
        if (term && !seen[key]) { seen[key] = true; items.push(term); }
      });
    } catch (ignore) {}
    return items;
  }
  function rememberQuery(query) {
    var key = query.toLowerCase();
    recentQueries = [query].concat(recentQueries.filter(function (term) {
      return term.toLowerCase() !== key;
    })).slice(0, 20);
    try { localStorage.setItem(RECENT_QUERY_KEY, JSON.stringify(recentQueries)); } catch (ignore) {}
  }
  function closeSearchChoices(restoreFocus) {
    if (!queryMenuOpener) { return; }
    var opener = queryMenuOpener;
    queryMenuOpener = null;
    opener.setAttribute('aria-expanded', 'false');
    $('search-choices').hidden = true;
    scheduleFit();
    if (restoreFocus && opener.offsetWidth) { focus(opener); }
  }
  function positionSearchChoices() {
    if (!queryMenuOpener) { return; }
    var form = queryMenuOpener.form, menu = $('search-choices');
    if (!form.offsetWidth) { closeSearchChoices(false); return; }
    var formBox = form.getBoundingClientRect(), anchorBox = menu.previousElementSibling.getBoundingClientRect();
    pixelStyle(menu, 'width', Math.round(formBox.width));
    pixelStyle(menu, 'marginLeft', Math.max(0, Math.round(formBox.left - anchorBox.left)));
  }
  function openSearchChoices(opener, edge) {
    if (queryMenuOpener === opener && !edge) { closeSearchChoices(true); return; }
    closeSearchChoices(false);
    var form = opener.form, input = form.querySelector('input');
    var menu = $('search-choices'), choices = $('recent-query-items');
    var anchor = form === $('home-search') ? form.parentNode : form;
    choices.textContent = '';
    recentQueries.slice(0, 10).forEach(function (term) {
      var choice = button(term, function () {
        $('home-query').value = term;
        $('query').value = term;
        closeSearchChoices(false);
        focus(input);
      }, 'recent-query-choice');
      choice.setAttribute('role', 'menuitem');
      choices.appendChild(choice);
    });
    $('recent-query-empty').hidden = choices.childElementCount > 0;
    if (anchor.nextElementSibling !== menu) { anchor.parentNode.insertBefore(menu, anchor.nextSibling); }
    queryMenuOpener = opener;
    opener.setAttribute('aria-expanded', 'true');
    menu.hidden = false;
    positionSearchChoices();
    menu.scrollTop = 0;
    focus((edge === 'last' ? choices.lastElementChild : choices.firstElementChild) || opener);
    scheduleFit();
  }
  function toggleSearchChoices(event) { openSearchChoices(event.currentTarget); }
  function handleSearchChoiceKey(event, code) {
    var active = document.activeElement, buttons, index;
    if (!queryMenuOpener) {
      if (code !== 38 && code !== 40) { return false; }
      if (active !== $('home-query-list') && active !== $('query-list')) { return false; }
      event.preventDefault();
      openSearchChoices(active, code === 38 ? 'last' : 'first');
      return true;
    }
    if (code === 27 || code === 461 || code === 37 || code === 39) {
      event.preventDefault(); closeSearchChoices(true); return true;
    }
    if (code !== 38 && code !== 40) { return false; }
    event.preventDefault();
    buttons = $('recent-query-items').querySelectorAll('button');
    if (!buttons.length) { return true; }
    index = Array.prototype.indexOf.call(buttons, active);
    focus(buttons[(index + (code === 40 ? 1 : -1) + buttons.length) % buttons.length]);
    return true;
  }
  function showResultsTab() {
    tab = 'results';
    listVisible = true;
    if (cinema) { exitFullscreen(); }
    applyViews();
    renderList();
  }
  function focusTrackRow(preferred) {
    var rows = $('tracks').querySelectorAll('[data-track]'), top = $('list-panel').getBoundingClientRect().top, firstVisible = null, i;
    for (i = 0; i < rows.length; i += 1) {
      if (rows[i].getAttribute('data-track') === preferred) { focus(rows[i]); return; }
      if (!firstVisible && rows[i].getBoundingClientRect().bottom > top + 1) { firstVisible = rows[i]; }
    }
    focus(firstVisible || rows[0] || $(tab === 'saved' ? 'show-saved' : 'show-results'));
  }
  function showCurrentResults() {
    var panel = $('list-panel'), scroll = tab === 'results' ? panel.scrollTop : 0;
    closeSearchChoices(false); showResultsTab(); panel.scrollTop = scroll; focusTrackRow('');
  }
  function openPlaybackList(browse) {
    if (cinema) { exitFullscreen(); }
    listVisible = true;
    if (browse) { playerView = false; }
    applyViews();
    focusTrackRow(lastListFocus || (current && current.id));
  }
  function focusPlayer() {
    playerView = true; videoVisible = true; applyViews(); focus($('player-label'));
  }
  function rememberList(key) {
    if (listKey && listKey !== key) {
      listTrail.push(captureVisit());
      if (listTrail.length > 12) { listTrail.shift(); }
    }
    listKey = key; syncPlayerHistory();
  }
  function canReturn() {
    return !!(listTrail.length || playerView || cinema || queryMenuOpener || !$('inline-panel').hidden || !$('pet-settings').hidden);
  }
  function syncPlayerHistory() {
    var previous = canReturn(); $('screen-back').disabled = !previous;
    if (historyBusy || historyHandling || !window.history || !window.history.pushState) { return; }
    try {
      var guarded = window.history.state && window.history.state.jaduTV === 'inside';
      if (!guarded) { window.history.pushState({jaduTV:'inside'},''); }
    } catch (ignore) { historyBusy = false; }
  }
  function previousScreen() {
    if (queryMenuOpener) { closeSearchChoices(true); }
    else if (!$('inline-panel').hidden) { closePanel(); }
    else if (!$('pet-settings').hidden) { $('pet-settings').hidden = true; focus($('pet-call')); }
    else if (playerView && !$('player-settings').hidden) { togglePlayerSettings(); }
    else if (cinema) { exitFullscreen(); focus($('player-label')); }
    else if (playerView) { openPlaybackList(true); }
    else if (listTrail.length) { restoreVisit(listTrail.pop()); }
    else { status('자두 TV의 첫 화면입니다.'); }
    syncPlayerHistory(); return true;
  }
  window.addEventListener('popstate',function () {
    if (historyBusy) { historyBusy = false; }
    else if (!(window.history.state && window.history.state.jaduTV === 'inside')) {
      historyHandling = true;
      try { previousScreen(); } finally { historyHandling = false; }
    }
    syncPlayerHistory();
  });

  function movePlaybackFocus(code, active) {
    if (!current || !frame || officialPlayback || !$('inline-panel').hidden || !$('pet-settings').hidden) { return false; }
    if ($('player-controls').contains(active)) { return false; }
    if (code === 39 && (cinema || (playerView && ($('player-panel').contains(active) || active === document.body)))) {
      openPlaybackList(false); return true;
    }
    if (code === 37 && active && (active.hasAttribute('data-track') || active === $('show-results') || active === $('show-saved'))) {
      focusPlayer(); return true;
    }
    return false;
  }

  function readWatched() { try { watched = C.read(localStorage.getItem(WATCHED_KEY)).slice(0, 100); } catch (e) { historyReadError = true; } }
  function recordWatched() {
    if (!current || recordedId === current.id) { return; } recordedId = current.id;
    watched = [track(current)].concat(watched.filter(function (item) { return item.id !== current.id; })).slice(0, 100);
    if (!historyReadError) { try { localStorage.setItem(WATCHED_KEY, C.write(watched)); } catch (ignore) { status('이번 감상 기록은 브라우저를 닫으면 사라질 수 있습니다.'); } }
  }
  function loadHome(category) {
    rememberList('home:' + (category || lastCategory));
    resetPaging();
    if (lastCategory === 'library' && category && category !== 'library') { tab = 'results'; }
    lastCategory = categoryLabels[category] ? category : lastCategory;
    var ticket = ++homeRequestId; if (homeRequest) { homeRequest.abort(); }
    requestId += 1; if (request) { request.abort(); }
    var chips = $('categories').querySelectorAll('button'), i;
    for (i = 0; i < chips.length; i += 1) { chips[i].setAttribute('aria-pressed', String(chips[i].getAttribute('data-category') === lastCategory)); }
    playerView = false; videoVisible = true; applyViews(); $('home-retry').hidden = true; $('cards').innerHTML = '';
    if (lastCategory === 'recommendations' || lastCategory === 'feed') {
      var kind = lastCategory, recommendations = kind === 'recommendations';
      var title = recommendations ? '자두 추천 · 내 구독·재생목록 기준' : categoryLabels.feed;
      var waiting = recommendations ? '내 계정에서 추천 영상을 고르는 중입니다.' : '내 구독 영상을 불러오는 중입니다.';
      tab = 'results'; listVisible = true; lastSearch = ''; selected = null;
      renderCards([], title, kind); applyViews();
      text($('home-message'), waiting); text($('empty-list'), waiting);
      var route = recommendations ? 'recommendations' : 'subscription-feed';
      homeRequest = accountRequest(route, 'GET', function (error, data) {
        if (ticket !== homeRequestId) { return; }
        if (error) {
          text($('home-message'), error); text($('empty-list'), error);
          $('home-retry').hidden = false;
          if (data && (data.error === 'reconnect' || data.error === 'not_connected')) { accountButton({connected:false}); }
          return;
        }
        var items = accountTracks(data,kind);
        if (recommendations) {
          if (data.source === 'subscriptions') { title = '자두 추천 · 내 구독 기준'; }
          else if (data.source === 'playlists') { title = '자두 추천 · 내 재생목록 기준'; }
        }
        renderCards(items, title, kind);
        beginPages('',title,accountCursor(data.nextCursor),kind,route);

        if (!items.length) {
          var empty = recommendations ? '내 구독과 재생목록에서 새로 추천할 영상이 없습니다.' : '구독 채널에서 불러올 새 영상이 없습니다.';
          text($('home-message'), empty); text($('empty-list'), empty);
        }
        status(categoryLabels[kind] + ' ' + items.length + '개');
      });
      return;
    }

    if (lastCategory === 'library') {
      tab = 'saved'; listVisible = true; selected = null; filter = ''; savedLimit = 20; $('saved-filter').value = '';
      renderCards([], '보관함'); applyViews();
      if (accountState.connected) {
        loadAccountCollections('playlists', '보관함 · 내 YouTube 재생목록',true);
      } else {
        showLocalItems(saved, '보관함 · 이 TV에 저장한 곡','library','library');
        if (!saved.length) { text($('home-message'), '이 TV에 저장한 곡이 없습니다. 로그인하면 내 YouTube 재생목록도 볼 수 있습니다.'); }
      }
      renderList();
      return;
    }
    if (lastCategory === 'watched') {
      tab = 'results'; showLocalItems(watched, '이 TV의 자두에서 감상한 동영상','watched','watched');
      if (!watched.length) { text($('home-message'), '아직 감상한 동영상이 없습니다. 자두에서 실제 재생한 영상이 여기에 표시됩니다.'); }
      return;
    }
    $('home-message').hidden = false; text($('home-message'), categoryLabels[lastCategory] + ' 동영상을 불러오는 중입니다.');
    homeRequest = fetchTracks(categoryQueries[lastCategory], function (error, items, cursor) {
      if (ticket !== homeRequestId) { return; }
      if (error) { text($('home-message'), error); $('home-retry').hidden = false; return; }
      beginPages(categoryQueries[lastCategory], categoryLabels[lastCategory], cursor, lastCategory);
      renderCards(items, categoryLabels[lastCategory]);
    });
  }
  function search(query) {
    query = C.clean(query, 200); if (!query) { status('노래 제목이나 가수를 입력해 주세요.'); return; }
    rememberList('search:' + query);
    rememberQuery(query); accountListKind = ''; text($('result-label'), '검색 결과');
    if (cinema) { exitFullscreen(); }
    resetPaging();
    var ticket = ++requestId; if (request) { request.abort(); } lastSearch = query; $('query').value = query; $('home-query').value = query;
    homeRequestId += 1; if (homeRequest) { homeRequest.abort(); }
    tab = 'results'; listVisible = true; playerView = false; results = []; renderList(); applyViews();
    $('cards').innerHTML = ''; $('home-message').hidden = false; $('home-retry').hidden = true;
    text($('browse-title'), '검색 결과'); text($('home-message'), '‘' + query + '’ 검색 중입니다…');
    text($('empty-list'), '검색 중입니다…'); status('‘' + query + '’ 검색 중입니다.');
    request = fetchTracks(query, function (error, items, cursor) {
      if (ticket !== requestId) { return; }
      if (error) {
        text($('empty-list'), error);
        text($('home-message'), error);
        status(error);
        return;
      }
      var title = '검색: ' + query;
      beginPages(query, title, cursor);
      renderCards(items, title);
      status('‘' + query + '’ 검색 결과 ' + items.length + '곡');
      var first = $('tracks').querySelector('button');
      if (first && !queryMenuOpener && !document.activeElement.hasAttribute('data-editing')) { focus(first); }
    });
  }
  function submitQuery(event, source) { if (event) { event.preventDefault(); } source = source || $('query'); finishEditing(source); var value = source.value.trim(), parsed = C.parse(value); if (parsed) { requestId += 1; if (request) { request.abort(); } queue = [parsed]; queuePages = null; selected = parsed; startTrack(parsed); } else if (/^https?:|youtube\.com|youtu\.be/i.test(value)) { status('지원하는 YouTube 영상 또는 재생목록 주소를 입력해 주세요.'); } else { search(value); } }
  function clockText(seconds) { seconds = Math.max(0, Math.floor(seconds || 0)); var minutes = Math.floor(seconds / 60), rest = seconds % 60; return minutes + ':' + (rest < 10 ? '0' : '') + rest; }
  function updatePlaybackControls() {
    text($('play'), playing ? '일시정지 Ⅱ' : '재생 ▶');
    ['player-toggle','player-mute','volume-down','volume-up'].forEach(function (id) { $(id).disabled = !playerReady; });
    text($('player-toggle'), playing ? '일시정지 Ⅱ' : '재생 ▶');
    if (!playerReady || !player) {
      $('seek').disabled = true; $('seek-back').disabled = true; $('seek-forward').disabled = true;
      $('seek').value = '0'; text($('playback-time'), '0:00 / 0:00'); return;
    }
    try {
      var duration = player.getDuration() || 0, position = player.getCurrentTime() || 0;
      var muted = player.isMuted(), volume = Math.round(player.getVolume());
      text($('playback-time'), clockText(position) + ' / ' + clockText(duration));
      $('seek').disabled = duration <= 0; $('seek-back').disabled = duration <= 0; $('seek-forward').disabled = duration <= 0;
      if (!seekDragging) { $('seek').value = duration > 0 ? String(Math.round(position / duration * 1000)) : '0'; }
      $('seek').setAttribute('aria-valuetext', clockText(position) + ' / ' + clockText(duration));
      text($('player-mute'), muted ? '소리 켜기' : '음소거'); $('player-mute').setAttribute('aria-pressed', String(muted));
      text($('volume-level'), muted ? '음소거' : volume + '%');
    } catch (ignore) {}
  }
  function seekTo(seconds) {
    if (!playerReady) { return; }
    try { var duration = player.getDuration(); if (duration > 0) { player.seekTo(Math.max(0,Math.min(duration,seconds)),true); } } catch (ignore) {}
    updatePlaybackControls();
  }
  function seekBy(seconds) { if (playerReady) { try { seekTo(player.getCurrentTime() + seconds); } catch (ignore) {} } }
  function commitSeek() {
    seekDragging = false;
    if (playerReady) { try { seekTo(Number($('seek').value) / 1000 * player.getDuration()); } catch (ignore) {} }
  }
  function changeVolume(delta) {
    if (!playerReady) { return; }
    try { player.setVolume(Math.max(0,Math.min(100,player.getVolume() + delta))); if (delta > 0) { player.unMute(); } } catch (ignore) {}
    updatePlaybackControls();
  }


  function syncPlayerSettings() {
    $('captions-default').setAttribute('aria-pressed',String(!captionsPreferred));
    $('captions-on').setAttribute('aria-pressed',String(captionsPreferred));
    $('captions-default').disabled = !playerReady;
    $('captions-on').disabled = !playerReady;
    var container = $('playback-rates'), activeRate = container.contains(document.activeElement) ? document.activeElement.textContent : '';
    container.textContent = '';
    if (!playerReady) { return; }
    try {
      var selectedRate = player.getPlaybackRate();
      player.getAvailablePlaybackRates().forEach(function (rate) {
        var control = button(String(rate) + '×',function () {
          if (playerReady) { player.setPlaybackRate(rate); }
        });
        control.setAttribute('aria-pressed',String(rate === selectedRate));
        container.appendChild(control);
        if (activeRate && activeRate === control.textContent) { focus(control); }
      });
    } catch (ignore) {}
  }
  function togglePlayerSettings() {
    var opening = $('player-settings').hidden;
    $('player-settings').hidden = !opening;
    $('player-settings-toggle').setAttribute('aria-expanded',String(opening));
    if (opening) { syncPlayerSettings(); } else { focus($('player-settings-toggle')); }
    scheduleFit();
  }
  function setCaptions(preferred) {
    if (!playerReady || captionsPreferred === preferred) { return; }
    try {
      resumePlayback = {time:player.getCurrentTime(),volume:player.getVolume(),muted:player.isMuted(),rate:player.getPlaybackRate(),index:current.listId ? player.getPlaylistIndex() : -1};
    } catch (ignore) { resumePlayback = null; }
    wantsPlay = playing || player.getPlayerState() === 3; captionsPreferred = preferred;
    try { localStorage.setItem('jadu-tv94-captions-v1',String(preferred)); } catch (ignore) {}
    buildFrame(); updatePlaybackControls(); syncPlayerSettings();
  }
  function resumePlayerSettings() {
    var state = resumePlayback; resumePlayback = null;
    if (!state) { return; }
    try {
      player.setVolume(state.volume);
      if (state.muted) { player.mute(); } else { player.unMute(); }
      player.seekTo(state.time,true); player.setPlaybackRate(state.rate);
      if (!wantsPlay) { player.pauseVideo(); }
    } catch (ignore) {}
  }
  function layoutPlayerControls() {
    var control = $('player-controls'), panel = $('player-panel');
    if (cinema && control.parentNode !== document.body) { document.body.appendChild(control); }
    else if (!cinema && control.parentNode !== panel) { panel.insertBefore(control,$('video-title')); }
    control.hidden = !playerView;
  }

  function playbackWatch() { clearTimeout(playTimer); playTimer = setTimeout(function () { if (wantsPlay && !playing) { status('영상 안의 재생 버튼을 눌러 주세요. TV가 자동 재생을 제한할 수 있습니다.'); } }, 15000); }
  function onState(event) { playing = event.data === 1; text($('player-label'), playing ? '재생 중' : event.data === 2 ? '일시정지' : event.data === 3 ? '불러오는 중' : '재생 대기'); if (playing) { wantsPlay = false; clearTimeout(playTimer); status('재생 중'); recordWatched(); } else if (event.data === 2) { wantsPlay = false; clearTimeout(playTimer); status('일시정지'); } else if (event.data === 0 && current && current.kind !== 'playlist') { nextTrack(1, true); } }
  function onError(event) { $('player-recovery').hidden = false; scheduleFit(); wantsPlay = false; playing = false; clearTimeout(playTimer); var messages = { 2:'영상 주소를 확인해 주세요.',5:'이 브라우저에서 영상을 재생하지 못했습니다.',100:'삭제되었거나 비공개인 영상입니다.',101:'이 영상은 외부 재생이 제한됩니다. 다른 곡을 선택하거나 YouTube에서 열어 주세요.',150:'이 영상은 외부 재생이 제한됩니다. 다른 곡을 선택하거나 YouTube에서 열어 주세요.',153:'YouTube가 접속 출처를 확인하지 못했습니다.' }; text($('player-label'), '재생 오류 ' + event.data); status((messages[event.data] || '다른 곡을 선택해 주세요.') + ' (' + event.data + ')'); }
  function connectAPI() { if (!apiReady || !frame || player) { return; } var ticket = generation; try { player = new window.YT.Player('yt-frame', { events: { onReady:function (event) { if (ticket !== generation) { return; } playerReady = true; fitPlayer(); resumePlayerSettings(); updatePlaybackControls(); syncPlayerSettings(); if (wantsPlay) { event.target.playVideo(); playbackWatch(); } },onStateChange:function (event) { if (ticket === generation) { onState(event); updatePlaybackControls(); } },onPlaybackRateChange:function () { if (ticket === generation && !$('player-settings').hidden) { syncPlayerSettings(); } },onError:function (event) { if (ticket === generation) { onError(event); } },onAutoplayBlocked:function () { if (ticket !== generation) { return; } wantsPlay = false; clearTimeout(playTimer); status('영상 안의 재생 버튼을 눌러 주세요.'); } } }); } catch (e) { status('플레이어 연결에 실패했습니다. 다시 재생을 눌러 주세요.'); } }
  function buildFrame() {
    generation += 1; playerReady = false; $('player-recovery').hidden = true; if (player) { try { player.destroy(); } catch (ignore) {} player = null; } $('video-mount').innerHTML = '';
    frame = node('iframe'); frame.id = 'yt-frame'; frame.title = 'YouTube 동영상'; frame.setAttribute('allow', 'autoplay; encrypted-media; fullscreen; picture-in-picture'); frame.setAttribute('allowfullscreen', ''); frame.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-presentation'); frame.setAttribute('referrerpolicy', 'origin'); frame.setAttribute('tabindex', '0');
    var params = 'enablejsapi=1&playsinline=1&autoplay=0&controls=1&fs=1&disablekb=0&rel=0&origin=' + encodeURIComponent(location.protocol + '//' + location.host);
    if (captionsPreferred) { params += '&cc_load_policy=1&cc_lang_pref=ko'; }
    if (resumePlayback) { params += '&start=' + Math.floor(resumePlayback.time); if (resumePlayback.index >= 0) { params += '&index=' + resumePlayback.index; } }
    if (current.listId) { params += '&list=' + encodeURIComponent(current.listId) + '&listType=playlist'; }
    // Fix the iframe viewport before the YouTube document/video is loaded.
    frame.setAttribute('scrolling', 'no'); frame.setAttribute('marginwidth', '0'); frame.setAttribute('marginheight', '0');
    $('video-mount').appendChild(frame); fitPlayer();
    frame.src = 'https://www.youtube.com/embed/' + (current.videoId || 'videoseries') + '?' + params; connectAPI();
  }
  function startTrack(value, paused) { resumePlayback = null; var next = track(value); if (!next) { return; } if (officialPlayback) { current = next; selected = next; if (!paused) { openOfficialTrack(next); } else { playerView = false; applyViews(); controls(); renderList(); } return; } current = next; selected = next; recordedId = ''; playing = false; wantsPlay = !paused; playerView = true; applyViews(); text($('player-label'), '연결 중'); status('영상을 준비하고 있습니다.'); buildFrame(); updatePlaybackControls(); syncPlayerSettings(); controls(); renderList(); if (!paused) { playbackWatch(); } }
  function play() { if (!current) { return; } if (officialPlayback) { openOfficialTrack(current); return; } if (!frame) { startTrack(current); return; } playerView = true; applyViews(); wantsPlay = true; if (playerReady) { try { player.playVideo(); } catch (e) { status('다시 재생을 눌러 주세요.'); } } playbackWatch(); }
  function pause() { wantsPlay = false; clearTimeout(playTimer); if (playerReady) { try { player.pauseVideo(); } catch (ignore) {} } }
  function nextTrack(delta, ended) { if (!current) { return; } if (current.kind === 'playlist') { if (playerReady) { if (delta > 0) { player.nextVideo(); } else { player.previousVideo(); } } return; } var index = -1; queue.forEach(function (t, i) { if (t.id === current.id) { index = i; } }); if (queue.length < 2 || (ended && index === queue.length - 1)) { if (ended) { status('목록 재생이 끝났습니다.'); } return; } startTrack(queue[(index + delta + queue.length) % queue.length]); }
  function fullscreenElement() { return document.fullscreenElement || document.webkitFullscreenElement || document.webkitCurrentFullScreenElement; }
  function resetFullscreen() { cinema = false; fullscreenNative = false; document.body.className = ''; $('fullscreen-exit').hidden = true; applyViews(); }
  function exitFullscreen() {
    var exit = document.exitFullscreen || document.webkitExitFullscreen || document.webkitCancelFullScreen;
    resetFullscreen();
    if (exit && fullscreenElement()) { try { var p = exit.call(document); if (p && p.catch) { p.catch(function () {}); } } catch (ignore) {} }
  }
  function fallbackFullscreen() { if (!cinema) { return; } fullscreenNative = false; $('fullscreen-exit').hidden = false; focus($('fullscreen-exit')); scheduleFit(); }
  function toggleFullscreen() {
    if (cinema || fullscreenElement()) { exitFullscreen(); return; }
    if (!current || !frame) { status('노래를 재생한 뒤 전체화면을 눌러 주세요.'); return; }
    cinema = true; playerView = true; videoVisible = true; document.body.className = 'video-fullscreen'; applyViews(); fitPlayer();
    // Put the page into native fullscreen so the fitted player keeps its own pixel size.
    var target = document.documentElement;
    var fn = target.requestFullscreen || target.webkitRequestFullscreen || target.webkitRequestFullScreen;
    fallbackFullscreen();
    // Older webOS video overlays can lose their rectangle during native fullscreen.
    if (/web0s|webos|netcast|smart.?tv/i.test(navigator.userAgent)) { return; }
    if (!fn) { return; }
    try { var p = fn.call(target); if (p && p.catch) { p.catch(fallbackFullscreen); } } catch (ignore) { fallbackFullscreen(); }
  }
  function captureVisit() {
    var active = document.activeElement;
    var state = { version:2,listKey:listKey,accountListKind:accountListKind,current:current,selected:selected,query:$('query').value,homeQuery:$('home-query').value,queue:queue,
      pagination:pages ? {query:pages.query, title:pages.title, cursor:pages.cursor, category:pages.category,route:pages.route,local:pages.local} : null,
      collections:collectionItems,savedLimit:savedLimit,queueFromResults:!!pages && queuePages === pages,
      results:results,browseTracks:browseTracks,browseTitle:$('browse-title').textContent,lastSearch:lastSearch,lastCategory:lastCategory,
      tab:tab,filter:filter,listVisible:listVisible,videoVisible:videoVisible,listScroll:$('list-panel').scrollTop,browseScroll:$('browse-panel').scrollTop,
      focusTrack:active && active.getAttribute('data-track'),focusCard:active && active.getAttribute('data-card') };
    return state;
  }
  function rememberVisit() {
    var state = captureVisit();
    try { var raw = JSON.stringify(state); sessionStorage.setItem(RETURN_KEY,raw); return sessionStorage.getItem(RETURN_KEY) === raw; } catch (ignore) { return false; }
  }
  function cancelListRequests() {
    resetPaging();
    requestId += 1; homeRequestId += 1;
    if (request) { request.abort(); request = null; } if (homeRequest) { homeRequest.abort(); homeRequest = null; }
  }
  function clearPlayer() {
    pause(); generation += 1; if (player) { try { player.destroy(); } catch (ignore) {} }
    player = null; frame = null; playerReady = false; playing = false; $('video-mount').innerHTML = '';
  }
  function openOfficialTrack(value) {
    var chosen = track(value); if (!chosen) { return; }
    current = chosen; selected = chosen;
    if (!rememberVisit()) { status('목록을 기억하지 못해 이동하지 않았습니다. 브라우저 저장 공간을 확인해 주세요.'); return; }
    cancelListRequests(); pause(); stopAccountPoll(); location.href = chosen.url;
  }
  function goOfficial(url) { var chosen = C.parse(url); if (chosen) { openOfficialTrack(current && current.url === chosen.url ? current : chosen); } }
  function restoreVisit(snapshot) {
    var raw, state = snapshot;
    if (!state) {
      try { raw = sessionStorage.getItem(RETURN_KEY); if (!raw) { return false; } state = JSON.parse(raw); if (!state || typeof state !== 'object') { return false; } }
      catch (ignore) { return false; }
    }
    cancelListRequests();
    if (!snapshot) { clearPlayer(); current = track(state.current); queue = normalizeList(state.queue); }
    selected = track(state.selected) || current; listKey = state.listKey || '';

    $('query').value = C.clean(state.query,4096); $('home-query').value = C.clean(state.homeQuery || state.query,200);
    lastSearch = C.clean(state.lastSearch,200); lastCategory = categoryLabels[state.lastCategory] ? state.lastCategory : 'all';
    tab = state.tab === 'saved' ? 'saved' : 'results'; filter = C.clean(state.filter,200); $('saved-filter').value = filter;
    listVisible = state.listVisible !== false; videoVisible = state.videoVisible !== false; playerView = false;
    cinema = false; fullscreenNative = false; document.body.className = ''; $('fullscreen-exit').hidden = true; $('inline-panel').hidden = true;
    var cards = normalizeList(state.browseTracks || state.results || state.queue);
    var previousPages = state.pagination;
    if (previousPages) {
      var previousCategory = categoryLabels[previousPages.category] ? previousPages.category : '';
      var title = C.clean(previousPages.title,250), cursor = previousPages.cursor;
      if (validAccountRoute(previousPages.route) && accountCursor(cursor)) {
        beginPages('',title,cursor,previousCategory,previousPages.route);
      } else if (Array.isArray(previousPages.local) && /^(watched|library)$/.test(previousCategory)) {
        var local = normalizeList(previousPages.local), offset = Number(cursor);
        if (offset > 0 && offset < local.length && offset % 20 === 0) { beginPages('',title,String(offset),previousCategory,'',local); }
      } else if (validCursor(cursor)) {
        beginPages(C.clean(previousPages.query,200),title,cursor,previousCategory);
      }
      if (state.queueFromResults === true && (!snapshot || (current && state.current && current.id === state.current.id))) { queuePages = pages; }
    }

    var kind = ['recommendations','feed','library','watched'].indexOf(state.accountListKind) >= 0 ? state.accountListKind : (state.accountFeed === true ? 'feed' : '');
    renderCards(cards, categoryLabels[kind] || '검색 결과', kind); text($('browse-title'),C.clean(state.browseTitle,250) || '검색 결과 · ' + cards.length + '개');
    if (Array.isArray(state.collections)) {
      collectionItems = state.collections.filter(function (item) { return item && typeof item.id === 'string' && (item.kind === 'playlist' || item.kind === 'channel'); });
      $('cards').innerHTML = ''; collectionItems.forEach(appendCollection); $('home-message').hidden = collectionItems.length > 0;
    }
    savedLimit = Math.max(20,Math.min(500,Number(state.savedLimit) || 20));
    results = normalizeList(state.results || state.queue); renderList(); applyViews();
    var chips = $('categories').querySelectorAll('button'), i;
    for (i = 0; i < chips.length; i += 1) { chips[i].setAttribute('aria-pressed',String(chips[i].getAttribute('data-category') === lastCategory)); }
    status('목록으로 돌아왔습니다. 다른 곡을 선택하거나 지금 곡을 저장할 수 있습니다.');
    setTimeout(function () {
      var buttons = document.querySelectorAll('[data-track],[data-card]'), target = null, j;
      for (j = 0; j < buttons.length; j += 1) {
        if ((state.focusTrack && buttons[j].getAttribute('data-track') === state.focusTrack) || (state.focusCard && buttons[j].getAttribute('data-card') === state.focusCard)) { target = buttons[j]; break; }
      }
      if (!target && selected) { for (j = 0; j < buttons.length; j += 1) { if (buttons[j].getAttribute('data-track') === selected.id) { target = buttons[j]; break; } } }
      focus(target || $('query'));
      $('list-panel').scrollTop = Math.max(0,Number(state.listScroll) || 0); $('browse-panel').scrollTop = Math.max(0,Number(state.browseScroll) || 0);
    },0);
    if (!snapshot) { try { sessionStorage.removeItem(RETURN_KEY); } catch (ignore) {} }
    return true;
  }
  function readPlaybackPreference() {
    try { var raw = localStorage.getItem(PLAYBACK_KEY); if (raw !== null) { var pref = JSON.parse(raw); officialPlayback = pref.version === 2 && pref.official === true; } } catch (ignore) {}
    $('tv-compatible').checked = officialPlayback; syncFitControl();
  }
  function setPlaybackPreference() {
    officialPlayback = $('tv-compatible').checked; syncFitControl(); if (cinema) { exitFullscreen(); }
    clearPlayer(); playerView = false; applyViews(); controls();
    try { localStorage.setItem(PLAYBACK_KEY,JSON.stringify({version:2,official:officialPlayback})); } catch (ignore) {}
    status(officialPlayback ? 'YouTube에서 재생: 곡을 누르면 YouTube로 이동하고, 뒤로 누르면 이 목록으로 돌아옵니다.' : '자두 화면 안에서 재생합니다.');
  }

  function officialPanel() { var body = openPanel('YouTube에서 열기'); body.appendChild(node('p', '공식 YouTube로 같은 창에서 이동합니다. 브라우저의 뒤로로 자두에 돌아올 수 있습니다.')); action('취소', closePanel); action('YouTube로 이동', function () { goOfficial(current.url); }, 'primary'); }

  function stopAccountPoll() { accountEpoch += 1; clearTimeout(accountTimer); accountTimer = null; }
  function accountButton(data) {
    accountState = data || {connected:false};
    text($('youtube-account'), accountState.connected ? '내 계정' : '로그인');
  }
  function accountRequest(route, method, done) {
    var xhr = new XMLHttpRequest(), finished = false;
    function finish(error, data) { if (finished) { return; } finished = true; done(error, data, xhr.status); }
    xhr.open(method, ACCOUNT_BASE + '/api/youtube/' + route, true); xhr.timeout = 25000;
    if (ACCOUNT_BASE) {
      var session = accountSession; try { session = localStorage.getItem(ACCOUNT_SESSION_KEY) || session; } catch (ignore) {}
      xhr.setRequestHeader('X-Jadu-Client','jadu-web');
      if (session) { xhr.setRequestHeader('Authorization','Bearer ' + session); }
    }
    if (method === 'POST') { xhr.setRequestHeader('Content-Type', 'application/json'); }
    xhr.onreadystatechange = function () { if (xhr.readyState !== 4) { return; } var data; try { data = JSON.parse(xhr.responseText); } catch (ignore) { data = {message:'계정 연결에 응답이 없습니다. 잠시 후 다시 눌러 주세요.'}; } if (ACCOUNT_BASE && (xhr.status === 401 || data.error === 'reconnect' || (route === 'status' && !data.connected && !data.pending))) { accountSession = ''; try { localStorage.removeItem(ACCOUNT_SESSION_KEY); } catch (ignore) {} } if (ACCOUNT_BASE && data.sessionToken) { accountSession = data.sessionToken; try { localStorage.setItem(ACCOUNT_SESSION_KEY,accountSession); } catch (ignore) {} delete data.sessionToken; } if (ACCOUNT_BASE && route === 'logout') { accountSession = ''; try { localStorage.removeItem(ACCOUNT_SESSION_KEY); } catch (ignore) {} } if (xhr.status < 200 || xhr.status >= 300) { finish(data.message || '계정 연결을 확인하지 못했습니다.', data); } else { finish(null, data); } };
    xhr.onerror = function () { finish('계정 연결에 접속하지 못했습니다.'); }; xhr.ontimeout = function () { finish('계정 연결 확인이 늦어지고 있습니다. 다시 눌러 주세요.'); };
    xhr.send(method === 'POST' ? '{}' : null); return xhr;
  }
  function refreshAccount(done) {
    var ticket = ++accountStatusTicket;
    accountRequest('status', 'GET', function (error, data) {
      if (ticket !== accountStatusTicket) { return; }
      if (!error) { accountButton(data); }
      else if (data && data.error === 'reconnect') { accountButton({connected:false}); status(data.message); }
      if (done) { done(); }
    });
  }
  function showAccountMenu() {
    var body = openPanel('내 YouTube 계정'); body.appendChild(node('p', accountState.label || 'YouTube 계정'));
    var menu = node('div', '', 'account-menu'); body.appendChild(menu);
    menu.appendChild(button('구독영상', function () { closePanel(); loadHome('feed'); }));
    menu.appendChild(button('내 재생목록', function () { loadAccountCollections('playlists', '내 재생목록'); }));
    menu.appendChild(button('내 구독', function () { loadAccountCollections('subscriptions', '내 구독'); }));
    action('이 기기 로그아웃', function () { accountRequest('logout', 'POST', function (error) { if (error) { status(error); return; } accountStatusTicket += 1; listTrail = []; listKey = ''; accountButton({connected:false,configured:true}); closePanel(); clearPlayer(); current = null; selected = null; queue = []; renderCards([],categoryLabels.all); loadHome('all'); status('이 기기의 계정 연결을 해제했습니다.'); }); });
  }
  function openAccount() {
    if (accountState.connected) { showAccountMenu(); return; }
    var body = openPanel('YouTube 계정 연결'), ticket = accountEpoch;
    body.appendChild(node('p', 'Google 연결 코드를 준비하고 있습니다.'));
    accountRequest('device/start', 'POST', function (error, data) {
      if (ticket !== accountEpoch) { return; } body.innerHTML = ''; $('inline-actions').innerHTML = '';
      if (error) { body.appendChild(node('p', error)); action('다시 확인', openAccount); return; }
      if (data.connected) { accountStatusTicket += 1; accountButton(data); closePanel(); loadHome('recommendations'); return; }
      body.appendChild(node('p', '휴대폰이나 노트북에서 아래 Google 주소를 열고 코드를 입력해 주세요.'));
      body.appendChild(node('p', data.verificationUrl, 'account-url'));
      body.appendChild(node('strong', data.userCode, 'account-code'));
      var message = node('p', 'Google에서 승인하면 이 TV가 자동으로 연결됩니다.'); message.id = 'account-progress'; body.appendChild(message);
      action('연결 취소', function () { stopAccountPoll(); accountRequest('device/cancel', 'POST', function () {}); closePanel(); });
      pollAccount(ticket, data.interval, Date.now() + data.expiresIn * 1000);
    });
  }
  function pollAccount(ticket, interval, expires) {
    if (ticket !== accountEpoch) { return; }
    accountTimer = setTimeout(function () {
      if (ticket !== accountEpoch) { return; }
      if (Date.now() >= expires) { text($('account-progress'), '코드가 만료되었습니다. 다시 로그인해 주세요.'); action('새 코드 받기', openAccount); return; }
      accountRequest('device/poll', 'POST', function (error, data) {
        if (ticket !== accountEpoch) { return; }
        if (!error && data.connected) { accountStatusTicket += 1; accountButton(data); closePanel(); loadHome('recommendations'); return; }
        if (error) {
          text($('account-progress'), error);
          if (data && ['not_authorized','expired','not_connected','configuration','device_setup'].indexOf(data.error) >= 0) { action('다시 로그인', openAccount); return; }
        }
        pollAccount(ticket, data && data.interval || Math.max(interval || 5, error ? 10 : 5), expires);
      });
    }, Math.max(5, interval || 5) * 1000);
  }
  function loadAccountCollections(route, title, fromHome) {
    if (!fromHome) { rememberList('collections:' + route); }
    resetPaging();
    closePanel(); var ticket = ++homeRequestId; requestId += 1; if (request) { request.abort(); } if (homeRequest) { homeRequest.abort(); }
    playerView = false; videoVisible = true; applyViews(); $('cards').innerHTML = ''; $('home-message').hidden = false; $('home-retry').hidden = true; text($('home-message'), title + '을 불러오는 중입니다.'); text($('browse-title'), title);
    homeRequest = accountRequest(route, 'GET', function (error, data) {
      if (ticket !== homeRequestId) { return; }
      if (error) { text($('home-message'), error); if (lastCategory === 'library') { $('home-retry').hidden = false; } if (data && data.error === 'reconnect') { accountButton({connected:false}); } return; }
      var items = data.collections || []; collectionItems = items;
      beginPages('',title,accountCursor(data.nextCursor),'',route); $('home-message').hidden = items.length > 0; text($('home-message'), lastCategory === 'library' ? '표시할 YouTube 재생목록이 없습니다. 이 TV에 저장한 곡은 오른쪽에서 볼 수 있습니다.' : '계정에 표시할 목록이 없습니다.');
      text($('browse-title'), title + ' · ' + items.length + '개');
      items.forEach(appendCollection);
    });
  }
  function appendCollection(item) {
    var card = node('div','','music-card account-collection');
    card.setAttribute('role','listitem');
    var control = button('',function () {
      loadAccountVideoRoute('videos?id=' + encodeURIComponent(item.id) + '&kind=' + encodeURIComponent(item.kind),item.title);
    });
    control.setAttribute('data-card',item.id);
    control.appendChild(node('strong',item.title));
    control.appendChild(node('small',item.kind === 'playlist' ? String(item.count) + '개 동영상' : '구독 채널'));
    card.appendChild(control); $('cards').appendChild(card);
    return control;
  }
  function loadAccountVideoRoute(route, title) {
    rememberList(route);
    resetPaging(); collectionItems = null;
    var ticket = ++homeRequestId; text($('browse-title'),title); $('cards').innerHTML = ''; $('home-message').hidden = false;
    text($('home-message'),'동영상을 불러오는 중입니다.');
    homeRequest = accountRequest(route,'GET',function (error,data) {
      if (ticket !== homeRequestId) { return; }
      if (error) { text($('home-message'),error); return; }
      tab = 'results'; listVisible = true; applyViews(); renderCards(normalizeList(data.tracks),title);
      beginPages('',title,accountCursor(data.nextCursor),'',route);
    });
  }

  function petPrefs() { $('pet-call').hidden = petHidden; $('pet-show').hidden = !petHidden; text($('pet-sound'), petSound ? '소리 끄기' : '소리 켜기'); try { localStorage.setItem('jadu-tv94-pet-v1', JSON.stringify({hidden:petHidden,sound:petSound,motion:false})); } catch (ignore) {} }
  function petMenu() { if (petSound) { try { if (!petAudio) { petAudio = new Audio('assets/pet/Sounds/meow.wav'); petAudio.volume = 0.3; } petAudio.currentTime = 0; var p = petAudio.play(); if (p && p.catch) { p.catch(function () {}); } } catch (ignore) {} } $('pet-settings').hidden = !$('pet-settings').hidden; if (!$('pet-settings').hidden) { focus($('pet-sound')); } }
  function isQuery(el) { return el === $('home-query') || el === $('query'); }
  function voiceTarget() {
    if (isQuery(document.activeElement)) { return document.activeElement; }
    return $('query').offsetWidth ? $('query') : $('home-query');
  }
  function prepareVoice(input) {
    closeSearchChoices(false); input.readOnly = false; input.setAttribute('data-editing','true'); focus(input);
    if (input.select && input.value) { input.select(); }
    status('리모컨 또는 TV 키보드의 마이크로 말한 뒤 검색을 누르세요.');
  }
  function bindVoice(buttonId,inputId) {
    var input = $(inputId);
    $(buttonId).addEventListener('click',function () { prepareVoice(input); });
    input.addEventListener('input',function () {
      input.setAttribute('data-editing','true');
      (inputId === 'query' ? $('home-query') : $('query')).value = input.value;
    });
  }
  function beginEditing(input) { input.readOnly = false; input.setAttribute('data-editing', 'true'); focus(input); }
  function finishEditing(input) { input.readOnly = !isQuery(input); input.removeAttribute('data-editing'); }
  function navigable() { var items = document.querySelectorAll('[data-nav]'), out = [], i, r; for (i = 0; i < items.length; i += 1) { if (items[i].disabled || !items[i].offsetWidth || !items[i].offsetHeight || (cinema && $('tv-shell').contains(items[i]) && !$('player-controls').contains(items[i]))) { continue; } r = items[i].getBoundingClientRect(); out.push({id:i,element:items[i],left:r.left,right:r.right,top:r.top,bottom:r.bottom}); } return out; }
  function move(direction) { var items = navigable(), from = null, chosen, i; for (i = 0; i < items.length; i += 1) { if (items[i].element === document.activeElement) { from = items[i]; break; } } if (!from) { focus($('query')); return; } chosen = C.neighbour(items, from, direction); for (i = 0; i < items.length; i += 1) { if (items[i].id === chosen) { focus(items[i].element); break; } } }
  document.addEventListener('compositionstart', function () { composing = true; }); document.addEventListener('compositionend', function () { composing = false; });
  document.addEventListener('click', function (event) { var el = event.target; if (el.tagName === 'INPUT' && el.type !== 'checkbox' && el.type !== 'range' && el.hasAttribute('data-nav')) { beginEditing(el); } });
  document.addEventListener('focusout', function (event) { var el = event.target; if (el.tagName === 'INPUT' && el.type !== 'checkbox' && el.type !== 'range') { if (isQuery(el) && !event.relatedTarget) { return; } finishEditing(el); } });
  document.addEventListener('keydown', function (event) {
    var code = event.keyCode || event.which, active = document.activeElement, editing = active && active.getAttribute('data-editing') === 'true';
    if (event.key === 'SpeechInputToggle' || event.key === 'VoiceInput') { prepareVoice(voiceTarget()); return; }
    if (composing || code === 229 || event.isComposing) { return; }
    if (event.key === 'BrowserBack' || event.key === 'GoBack' || (code === 37 && event.altKey) || (code === 8 && !editing)) { code = 461; }
    if (handleSearchChoiceKey(event, code)) { return; }
    if (active === $('seek') && (code === 37 || code === 39 || code === 13)) {
      event.preventDefault(); if (code === 13) { commitSeek(); } else { seekBy(code === 37 ? -5 : 5); } return;
    }
    if (editing) { if (code === 13) { event.preventDefault(); finishEditing(active); if (active === $('query') || active === $('home-query')) { submitQuery(null, active); } else if (active === $('saved-filter')) { filter = active.value; savedLimit = 20; renderList(); focus($('filter-saved')); } else { focus($('inline-actions').lastChild); } } else if (code === 461 || code === 27) { event.preventDefault(); finishEditing(active); focus(active); } return; }
    if (code >= 37 && code <= 40) { event.preventDefault(); if (!movePlaybackFocus(code, active)) { move({37:'left',38:'up',39:'right',40:'down'}[code]); } }
    else if (code === 13 && active && active.tagName === 'INPUT') { event.preventDefault(); if (active.type === 'checkbox') { active.click(); } else { beginEditing(active); } }
    else if (code === 461 || code === 27) { if (previousScreen()) { event.preventDefault(); } }

    else if (code === 415 || code === 179) { event.preventDefault(); if (playing && code === 179) { pause(); } else { play(); } } else if (code === 19 || code === 413) { event.preventDefault(); pause(); } else if (code === 412 || code === 417) { event.preventDefault(); seekBy(code === 412 ? -10 : 10); }
  });
  bindVoice('home-voice','home-query'); bindVoice('list-voice','query');
  $('screen-back').addEventListener('click',previousScreen);
  document.addEventListener('click',syncPlayerHistory);
  $('address-form').addEventListener('submit', function (e) { submitQuery(e, $('query')); }); $('home-search').addEventListener('submit', function (e) { submitQuery(e, $('home-query')); });
  $('show-all').addEventListener('click', function () { tab = 'saved'; filter = ''; savedLimit = 20; $('saved-filter').value = ''; renderList(); status('저장한 곡 ' + saved.length + '개'); });
  $('show-saved').addEventListener('click', function () { tab = 'saved'; renderList(); }); $('show-results').addEventListener('click', showCurrentResults);
  $('filter-saved').addEventListener('click', function () { filter = $('saved-filter').value; savedLimit = 20; finishEditing($('saved-filter')); renderList(); });
  $('save').addEventListener('click', saveTrack); $('delete').addEventListener('click', deleteTrack); $('undo-delete').addEventListener('click', undoDelete); $('inline-close').addEventListener('click', closePanel);
  $('play').addEventListener('click', function () { if (playing) { pause(); } else { play(); } }); $('pause').addEventListener('click', pause); $('previous').addEventListener('click', function () { nextTrack(-1); }); $('next').addEventListener('click', function () { nextTrack(1); });
  $('home').addEventListener('click', function () { pause(); loadHome(accountState.connected ? 'recommendations' : 'all'); }); $('home-retry').addEventListener('click', function () { loadHome(); });
  $('categories').addEventListener('click', function (e) { var q = e.target.getAttribute('data-category'); if (!q) { return; } var items = $('categories').querySelectorAll('button'), i; for (i = 0; i < items.length; i += 1) { items[i].setAttribute('aria-pressed', String(items[i] === e.target)); } pause(); loadHome(q); });
  $('browse').addEventListener('click', function () { openPlaybackList(true); });
  $('return-player').addEventListener('click', focusPlayer);
  $('player-label').addEventListener('click', function () { if (playing) { pause(); } else { play(); } });
  $('tracks').addEventListener('focusin', function (e) { var id = e.target.getAttribute('data-track'); if (id) { lastListFocus = id; } });
  $('retry').addEventListener('click', function () { if (current) { startTrack(current); } }); $('youtube-account').addEventListener('click', openAccount);
  window.addEventListener('resize', scheduleFit); window.addEventListener('orientationchange', scheduleFit); document.addEventListener('click', scheduleFit); window.addEventListener('load', scheduleFit);
  if (window.visualViewport) { window.visualViewport.addEventListener('resize', scheduleFit); }
  setInterval(reportDisplay, 30000);
  $('fullscreen').addEventListener('click', toggleFullscreen); $('fullscreen-exit').addEventListener('click', exitFullscreen); $('toggle-list').addEventListener('change', function () { var value = this.checked; if (cinema) { exitFullscreen(); } listVisible = value; applyViews(); }); $('toggle-video').addEventListener('change', function () { var value = this.checked; if (cinema) { exitFullscreen(); } videoVisible = value; applyViews(); });
  function fullscreenChanged() {
    var active = fullscreenElement(), page = active === document.documentElement && cinema;
    if (active && (page || active === frame || active === $('video-mount'))) {
      cinema = true; fullscreenNative = true; document.body.className = 'video-fullscreen';
      $('fullscreen-exit').hidden = !page; applyViews();
    } else if (!active && fullscreenNative) { resetFullscreen(); focus($('player-label')); }
    scheduleFit();
  }
  document.addEventListener('fullscreenchange', fullscreenChanged);
  document.addEventListener('webkitfullscreenchange', fullscreenChanged);
  $('pet-call').addEventListener('click', petMenu); $('pet-close').addEventListener('click', function () { $('pet-settings').hidden = true; focus($('pet-call')); }); $('pet-sound').addEventListener('click', function () { petSound = !petSound; if (!petSound && petAudio) { petAudio.pause(); } petPrefs(); }); $('pet-hide').addEventListener('click', function () { petHidden = true; if (petAudio) { petAudio.pause(); } $('pet-settings').hidden = true; petPrefs(); focus($('pet-show')); }); $('pet-show').addEventListener('click', function () { petHidden = false; petPrefs(); focus($('pet-call')); });
  window.onYouTubeIframeAPIReady = function () { apiReady = true; connectAPI(); };
  function loadAPI() { if (window.YT && window.YT.Player) { window.onYouTubeIframeAPIReady(); return; } var script = node('script'); script.src = 'https://www.youtube.com/iframe_api'; script.async = true; script.onerror = function () { status('YouTube 재생 연결을 불러오지 못했습니다.'); }; document.head.appendChild(script); }
  // Place the video outside scrolling/flex ancestors for the TV video compositor.
  $('video-mount').className = 'flat-video-host'; document.body.appendChild($('video-mount'));
  window.addEventListener('scroll', scheduleFit, true);
  $('tv-compatible').addEventListener('change',setPlaybackPreference);
  $('fixed-fit').addEventListener('click',changeFitPreference);
  $('home-query-list').addEventListener('click', toggleSearchChoices);
  $('query-list').addEventListener('click', toggleSearchChoices);
  window.addEventListener('resize', positionSearchChoices);
  function dismissSearchChoices(event) {
    if (queryMenuOpener && !queryMenuOpener.contains(event.target) && !$('search-choices').contains(event.target)) { closeSearchChoices(false); }
  }
  document.addEventListener('click', dismissSearchChoices);
  document.addEventListener('focusin', dismissSearchChoices);
  recentQueries = readRecentQueries();
  $('player-toggle').addEventListener('click',function () { if (playing) { pause(); } else { play(); } });
  $('seek-back').addEventListener('click',function () { seekBy(-10); });
  $('seek-forward').addEventListener('click',function () { seekBy(10); });
  $('seek').addEventListener('input',function () { seekDragging = true; });
  $('seek').addEventListener('change',commitSeek);
  $('seek').addEventListener('blur',function () { seekDragging = false; });
  $('player-mute').addEventListener('click',function () { if (!playerReady) { return; } if (player.isMuted()) { player.unMute(); } else { player.mute(); } updatePlaybackControls(); });
  $('volume-down').addEventListener('click',function () { changeVolume(-10); });
  $('volume-up').addEventListener('click',function () { changeVolume(10); });
  $('player-settings-toggle').addEventListener('click',togglePlayerSettings);
  $('captions-default').addEventListener('click',function () { setCaptions(false); });
  $('captions-on').addEventListener('click',function () { setCaptions(true); });
  try { captionsPreferred = localStorage.getItem('jadu-tv94-captions-v1') === 'true'; } catch (ignore) {}
  setInterval(function () { if (playerView && videoVisible) { updatePlaybackControls(); } },1000);
  $('browse-more').addEventListener('click', loadMore);
  $('list-more').addEventListener('click', loadMore);
  window.addEventListener('pageshow',function (e) { if (e.persisted) { restoreVisit(); refreshAccount(); } });
  readFitPreference(); readPlaybackPreference(); readStorage(); readWatched(); try { var prefs = JSON.parse(localStorage.getItem('jadu-tv94-pet-v1') || '{}'); petHidden = prefs.hidden === true; petSound = prefs.sound !== false; } catch (ignore) {} petPrefs(); renderList(); applyViews(); loadAPI();
  if (restoreVisit()) { refreshAccount(); }
  else {
    var initialHome = homeRequestId, initialSearch = requestId;
    focus(/web0s|webos|netcast|smart.?tv/i.test(navigator.userAgent) ? $('home') : $('query'));
    if (officialPlayback) { status('YouTube에서 재생: 곡을 누르면 YouTube로 이동하고, 뒤로 누르면 목록으로 돌아옵니다.'); }
    loadHome('all'); initialHome = homeRequestId;
    refreshAccount(function () {
      if (initialHome === homeRequestId && initialSearch === requestId && !current && accountState.connected && tab === 'results' && $('inline-panel').hidden) {
        var initialCategory = accountState.connected && tab === 'results' ? 'recommendations' : 'all';
        loadHome(initialCategory);
      }
    });
  }
  window.jaduTV94Ready = true; text($('tv-start-status'),'TV 94');
}());
