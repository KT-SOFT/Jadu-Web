(function () {
  'use strict';
  var C = window.JaduTVCore;
  var KEY = 'jadu-tv-library-v1';
  var tracks = [], current = null, filterTerm = '', queue = [], player = null, frame = null;
  var apiReady = false, playerReady = false, playing = false, playRequested = false, stateCode = null;
  var storageOK = false, storageReadError = false, modal = false, returnFocus = null;
  var receivedPlaying = false, confirmedAV = false, lastError = '', lastKey = '', events = [];
  var apiTimer = null, playTimer = null, petTimer = null, petIndex = 0, generation = 0;
  var bootTime = new Date();
  function $(id) { return document.getElementById(id); }
  function text(element, value) { element.textContent = value; }
  function log(message) {
    events.push(new Date().toLocaleTimeString() + ' ' + message);
    if (events.length > 24) { events.shift(); }
    if (modal && $('diag-log')) { refreshDiagnostics(); }
  }
  function status(message) { text($('status'), message); }
  function node(tag, content, className) {
    var element = document.createElement(tag);
    if (typeof content === 'string') { text(element, content); }
    if (className) { element.className = className; }
    return element;
  }
  function button(label, fn, className) {
    var element = node('button', label, className); element.type = 'button'; element.setAttribute('data-nav', '');
    element.addEventListener('click', fn); return element;
  }
  function focus(element) {
    if (!element || element.disabled) { return; }
    element.focus();
    if (element.getAttribute('data-track')) { element.scrollIntoView(false); }
  }
  function closeSheet() {
    if (!modal) { return; }
    modal = false; $('overlay').hidden = true;
    if (returnFocus && document.documentElement.contains(returnFocus) && !returnFocus.disabled) { focus(returnFocus); }
    else { focus($('query')); }
  }
  function sheet(title) {
    if (!modal) { returnFocus = document.activeElement; }
    modal = true; text($('sheet-title'), title); $('sheet-body').innerHTML = ''; $('sheet-actions').innerHTML = '';
    $('overlay').hidden = false; focus($('sheet-close'));
    return $('sheet-body');
  }
  function paragraph(body, content, className) { body.appendChild(node('p', content, className)); }
  function actions(element) { $('sheet-actions').appendChild(element); }
  function readStorage() {
    try {
      var raw = window.localStorage.getItem(KEY);
      tracks = C.read(raw);
      storageOK = true;
      text($('storage'), 'TV에 저장');
    } catch (error) {
      storageReadError = true; storageOK = false; text($('storage'), '저장 자료 확인 필요'); $('storage').className = 'storage error';
      status('저장 자료를 읽지 못했어요. 기존 자료를 덮어쓰지 않고 재생만 사용할 수 있어요.');
    }
  }
  function persist(next) {
    if (storageReadError) { status('기존 저장 자료를 읽지 못해 덮어쓰기를 막았어요. TV 확인 내용을 알려 주세요.'); return false; }
    try {
      var data = C.write(next); window.localStorage.setItem(KEY, data);
      if (window.localStorage.getItem(KEY) !== data) { throw new Error('readback'); }
      tracks = next; storageOK = true; text($('storage'), 'TV에 저장됨'); $('storage').className = 'storage'; return true;
    } catch (error) {
      storageOK = false; text($('storage'), '저장 실패'); $('storage').className = 'storage error';
      status('TV 브라우저에 저장하지 못했어요. 목록은 이전 상태로 유지합니다.'); log('목록 저장 실패'); return false;
    }
  }
  function renderList() {
    var old = document.activeElement, restoreID = old && old.getAttribute('data-track'), restoreAction = old && old.getAttribute('data-action');
    var visible = C.filter(tracks, filterTerm); $('tracks').innerHTML = ''; text($('count'), String(tracks.length));
    text($('list-caption'), filterTerm ? '저장곡 검색: ' + filterTerm + ' · ' + visible.length + '개' : '목록에서 확인을 누르면 재생합니다.');
    $('empty-list').hidden = visible.length > 0;
    text($('empty-list'), filterTerm ? '일치하는 저장곡이 없어요.' : '아직 저장한 곡이 없어요. 주소를 열고 ‘노래 저장’을 눌러 주세요.');
    visible.forEach(function (track, index) {
      var row = node('div', '', 'track' + (current && current.id === track.id ? ' current' : '')); row.setAttribute('role', 'listitem');
      var main = button('', function () { queue = visible.slice(); startTrack(track); }, 'track-main');
      main.setAttribute('data-track', track.id); main.setAttribute('data-action', 'play'); main.setAttribute('aria-label', track.title + ' 재생');
      main.appendChild(node('strong', track.title)); main.appendChild(node('small', String(index + 1).replace(/^([0-9])$/, '0$1') + ' · ' + (track.kind === 'playlist' ? 'YouTube 재생목록' : 'YouTube')));
      var remove = button('삭제', function () { deleteTrack(track); }, 'track-delete');
      remove.setAttribute('data-track', track.id); remove.setAttribute('data-action', 'delete'); remove.setAttribute('aria-label', track.title + ' 삭제');
      row.appendChild(main); row.appendChild(remove); $('tracks').appendChild(row);
      if (restoreID === track.id && !modal) { focus(restoreAction === 'delete' ? remove : main); }
    });
    if (restoreID && !document.documentElement.contains(old) && !modal && document.activeElement === document.body) { focus($('show-all')); }
  }
  function controls() {
    text($('current-title'), current ? current.title : 'YouTube 주소를 열어 주세요.');
    ['play', 'pause', 'save', 'external', 'retry'].forEach(function (id) { $(id).disabled = !current; });
    $('previous').disabled = !current || (current.kind !== 'playlist' && queue.length < 2);
    $('next').disabled = $('previous').disabled;
    $('video-focus').disabled = !frame;
    if (!current) { text($('player-label'), '재생 대기'); }
    else if (playing) { text($('player-label'), '재생 중'); }
    else if (stateCode === 2) { text($('player-label'), '일시정지'); }
    else if (lastError) { text($('player-label'), '재생 확인 필요'); }
    else { text($('player-label'), '재생 대기'); }
  }
  function petAnimation() {
    clearTimeout(petTimer);
    if (document.hidden) { return; }
    var name = playing ? 'happy' : 'idle';
    $('pet').src = 'assets/pet/Frames/' + name + '/frame_0' + (petIndex % 8) + '.png';
    petIndex += 1; petTimer = setTimeout(petAnimation, playing ? 200 : 170);
  }
  function playbackWatch() {
    clearTimeout(playTimer);
    playTimer = setTimeout(function () {
      if (playRequested && !playing && !lastError) {
        status('재생 신호를 기다리고 있어요. 영상 안의 재생 버튼도 눌러 보세요. ‘TV 확인’에서 상태를 볼 수 있어요.'); log('재생 요청 후 18초 동안 재생 신호 없음');
      }
    }, 18000);
  }
  function onState(event) {
    stateCode = event.data; log('YouTube 상태 ' + stateCode);
    playing = stateCode === 1;
    if (playing) {
      receivedPlaying = true; playRequested = false; lastError = ''; clearTimeout(playTimer);
      text($('verification'), confirmedAV ? '영상·소리 직접 확인함' : '이 브라우저 재생 신호 확인'); $('verification').className = 'badge success';
      status('YouTube에서 재생 신호를 받았어요. 영상과 소리가 나오는지 확인해 주세요.');
      text($('pet-message'), '좋아. 같이 듣자.');
    } else if (stateCode === 2) {
      playRequested = false; clearTimeout(playTimer); status('일시정지했어요.'); text($('pet-message'), '여기서 기다리고 있을게.');
    } else if (stateCode === 0 && current && current.kind !== 'playlist') {
      clearTimeout(playTimer); playRequested = false; nextTrack(1, true);
    }
    controls();
  }
  function onError(event) {
    var code = Number(event.data), messages = {
      2: 'YouTube 주소나 영상 번호를 확인해 주세요.',
      5: 'TV 브라우저에서 이 영상을 재생하지 못했어요. 다른 영상도 시험해 주세요.',
      100: '삭제되었거나 비공개인 영상입니다.',
      101: '영상 소유자가 외부 화면 재생을 허용하지 않았어요.',
      150: '영상 소유자가 외부 화면 재생을 허용하지 않았어요.',
      153: 'YouTube가 페이지의 출처를 확인하지 못했어요. 정상적인 웹 주소에서 다시 열어 주세요.'
    };
    playing = false; playRequested = false; clearTimeout(playTimer);
    lastError = 'YouTube 오류 ' + code; log(lastError); status((messages[code] || 'YouTube에서 재생 오류가 발생했어요.') + ' (오류 ' + code + ')'); controls();
  }
  function connectAPI() {
    if (!apiReady || !frame || player) { return; }
    var myGeneration = generation;
    try {
      player = new window.YT.Player('yt-frame', { events: {
        onReady: function (event) {
          if (myGeneration !== generation) { return; }
          playerReady = true; clearTimeout(apiTimer); log('YouTube 플레이어 준비 완료');
          if (playRequested) { event.target.playVideo(); playbackWatch(); }
          controls();
        },
        onStateChange: function (event) { if (myGeneration === generation) { onState(event); } },
        onError: function (event) { if (myGeneration === generation) { onError(event); } },
        onAutoplayBlocked: function () {
          if (myGeneration !== generation) { return; }
          playRequested = false; clearTimeout(playTimer); log('브라우저가 재생 시작을 제한함');
          status('브라우저가 재생 시작을 제한했어요. 영상 안의 재생 버튼을 직접 눌러 주세요.');
        }
      }});
    } catch (error) { log('YouTube API 연결 예외'); status('플레이어 연결이 안 됐어요. 영상 안에서 직접 재생하거나 다시 연결해 주세요.'); }
  }
  function buildFrame() {
    generation += 1; playerReady = false;
    if (player) { try { player.destroy(); } catch (ignore) { /* Keep the new frame independent. */ } player = null; }
    $('video-mount').innerHTML = '';
    frame = document.createElement('iframe'); frame.id = 'yt-frame'; frame.title = 'YouTube 동영상';
    frame.setAttribute('allow', 'autoplay; encrypted-media; fullscreen; picture-in-picture'); frame.setAttribute('allowfullscreen', '');
    frame.setAttribute('referrerpolicy', 'origin'); frame.setAttribute('tabindex', '-1');
    var origin = window.location.protocol + '//' + window.location.host;
    var params = 'enablejsapi=1&playsinline=1&autoplay=0&origin=' + encodeURIComponent(origin) + '&rel=0';
    if (current.listId) { params += '&list=' + encodeURIComponent(current.listId) + '&listType=playlist'; }
    frame.src = 'https://www.youtube.com/embed/' + (current.videoId || 'videoseries') + '?' + params;
    $('video-mount').appendChild(frame); $('video-empty').hidden = true;
    connectAPI();
  }
  function startTrack(track) {
    if (window.location.protocol !== 'http:' && window.location.protocol !== 'https:') {
      status('파일을 직접 열면 YouTube 재생이 제한됩니다. TV_시험시작.ps1로 웹 주소를 열어 주세요.'); return;
    }
    current = C.normalize(track); lastError = ''; playing = false; stateCode = null; playRequested = true;
    status('YouTube 영상을 준비하고 있어요. 처음에는 영상의 재생 버튼을 눌러야 할 수 있어요.');
    log('재생 요청: ' + current.kind);
    buildFrame(); controls(); renderList(); playbackWatch(); focus($('play'));
  }
  function play() {
    if (!current) { return; }
    if (!playerReady) { playRequested = true; status('연결을 기다리고 있어요. 영상 안에서도 재생할 수 있어요.'); playbackWatch(); return; }
    try { playRequested = true; lastError = ''; player.playVideo(); playbackWatch(); } catch (error) { status('재생 명령을 전달하지 못했어요. 다시 연결해 주세요.'); }
  }
  function pause() {
    playRequested = false; clearTimeout(playTimer);
    if (playerReady) { try { player.pauseVideo(); } catch (error) { status('일시정지 명령을 전달하지 못했어요.'); } }
    else { status('아직 재생 제어가 연결되지 않았어요. YouTube 화면의 일시정지를 사용해 주세요.'); }
  }
  function nextTrack(delta, ended) {
    if (!current) { return; }
    if (current.kind === 'playlist') {
      if (playerReady) { try { if (delta > 0) { player.nextVideo(); } else { player.previousVideo(); } } catch (error) { status('YouTube 목록 이동을 처리하지 못했어요.'); } }
      return;
    }
    if (queue.length < 2) { if (ended) { status('재생이 끝났어요.'); } return; }
    var index = -1; queue.forEach(function (track, i) { if (track.id === current.id) { index = i; } });
    if (ended && index === queue.length - 1) { status('목록 재생이 끝났어요.'); return; }
    startTrack(queue[(index + delta + queue.length) % queue.length]);
  }
  function saveTrack() {
    if (!current) { return; }
    if (tracks.some(function (item) { return item.id === current.id; })) { status('이미 저장한 곡이에요.'); return; }
    if (tracks.length >= 500) { status('최대 500개까지 저장할 수 있어요.'); return; }
    var chosen = C.normalize(current), body = sheet('노래 저장');
    paragraph(body, 'TV에 표시할 이름을 정해 주세요.');
    var label = node('label', '노래 이름'); label.htmlFor = 'save-title'; body.appendChild(label);
    var input = node('input'); input.id = 'save-title'; input.value = chosen.title; input.maxLength = 200; input.setAttribute('data-nav', ''); input.readOnly = true;
    body.appendChild(input); paragraph(body, chosen.url, 'detail');
    actions(button('취소', closeSheet));
    actions(button('저장', function () {
      chosen.title = C.clean(input.value, 200) || chosen.title;
      if (persist(tracks.concat([chosen]))) {
        if (current && current.id === chosen.id) { current.title = chosen.title; }
        closeSheet(); renderList(); controls(); status('이 TV의 저장 목록에 넣었어요.');
      }
    }, 'primary'));
    focus(input);
  }
  function deleteTrack(track) {
    var body = sheet('저장 목록에서 삭제'); paragraph(body, '‘' + track.title + '’ 곡을 저장 목록에서 지울까요?');
    actions(button('취소', closeSheet));
    actions(button('삭제', function () {
      var next = tracks.filter(function (item) { return item.id !== track.id; });
      if (persist(next)) { queue = queue.filter(function (item) { return item.id !== track.id; }); closeSheet(); renderList(); status('저장 목록에서 삭제했어요.'); }
    }, 'destructive'));
    focus($('sheet-actions').firstChild);
  }
  function submitQuery(event) {
    if (event) { event.preventDefault(); }
    finishEditing($('query'));
    var query = $('query').value.trim(), track = C.parse(query);
    if (track) { filterTerm = ''; queue = [track]; startTrack(track); }
    else if (/^https?:|youtube\.com|youtu\.be/i.test(query)) { status('지원하는 YouTube 영상·재생목록 주소를 넣어 주세요.'); }
    else { filterTerm = C.clean(query); renderList(); status(filterTerm ? '저장 목록에서만 검색했어요. YouTube 전체 키워드 검색 연결은 보류 중입니다.' : '저장 목록 전체를 표시했어요.'); }
  }
  function showHelp() {
    var body = sheet('리모컨으로 사용하는 방법');
    paragraph(body, '방향키로 보라색 테두리를 옮기고 확인을 누르세요. 입력칸에서 확인을 누르면 글자를 입력할 수 있어요. 입력을 마친 뒤 ‘열기 · 찾기’를 선택하세요.');
    paragraph(body, 'YouTube 주소를 열고 ‘노래 저장’을 누르면 이 TV 브라우저에 저장됩니다. 저장곡에서는 확인 한 번으로 재생합니다. 삭제는 곡 오른쪽에서 선택하세요.');
    paragraph(body, '노래·가수 이름은 저장 목록 안에서만 찾습니다. YouTube 전체 검색, Google 로그인·기기 간 동기화, AI 대화는 이 TV 시험판에 연결하지 않았습니다.');
    paragraph(body, '영상 안의 버튼을 조작해야 하면 ‘YouTube 화면 조작’을 누르세요. 화면 안에 들어가면 리모컨 뒤로 키가 자두로 전달되지 않을 수 있습니다. 매직 리모컨 포인터로 자두 버튼을 눌러 돌아올 수 있어요.');
    paragraph(body, '뒤로 키가 페이지에 전달되면 열린 창을 닫습니다. 인터넷 앱이 뒤로 키를 먼저 처리하면 이전 페이지로 이동할 수 있어요. 화면의 닫기 버튼도 사용할 수 있습니다.');
    paragraph(body, 'TV 인터넷 앱을 벗어나거나 전원을 끈 뒤의 재생, 다른 앱 위에 자두 표시, 브라우저 자료 삭제 뒤의 목록 복원은 제공하지 않습니다. 저장 목록은 폰·PC와 별개입니다.');
    paragraph(body, '2018 LG OLED55B8CNA의 실제 영상·소리·방향키·한글 입력·재실행 뒤 저장 복원을 확인해야 합니다.', 'detail');
  }
  function diagnosticsText() {
    return '자두 TV 시험판 0.1 / 시작 ' + bootTime.toLocaleString() + '\n' +
      '페이지: ' + window.location.protocol + '//' + window.location.host + '\n' +
      '브라우저: ' + navigator.userAgent + '\n화면: ' + window.innerWidth + ' × ' + window.innerHeight + '\n' +
      'YouTube API: ' + (apiReady ? '불러옴' : '응답 전') + '\n플레이어: ' + (playerReady ? '준비됨' : '준비 전') + '\n' +
      '현재 상태: ' + (stateCode === null ? '수신 전' : stateCode) + '\n재생 신호 수신: ' + (receivedPlaying ? '예' : '아니요') + '\n' +
      '영상·소리 직접 확인: ' + (confirmedAV ? '확인 버튼 누름' : '확인 전') + '\n마지막 오류: ' + (lastError || '없음') + '\n' +
      '저장 접근: ' + (storageOK ? '가능 (재실행 복원 별도 확인)' : '확인 필요') + '\n저장곡: ' + tracks.length + '\n마지막 키: ' + (lastKey || '수신 전') + '\n\n' + events.join('\n');
  }
  function refreshDiagnostics() { if ($('diag-log')) { text($('diag-log'), diagnosticsText()); } }
  function showDiagnostics() {
    var body = sheet('이 TV에서 확인할 내용');
    paragraph(body, '① 영상과 소리 ② 일시정지·재생 ③ 방향키·확인·뒤로 ④ 한글 입력 ⑤ 저장 후 인터넷 앱을 닫았다 열어 목록 복원');
    paragraph(body, '아래 ‘재생 신호’는 YouTube가 보낸 상태입니다. 실제 영상과 소리가 모두 나오는지 직접 확인해 주세요.', 'detail');
    var pre = node('pre'); pre.id = 'diag-log'; body.appendChild(pre); refreshDiagnostics();
    var confirm = button('영상·소리 확인했어요', function () {
      if (!receivedPlaying) { paragraph(body, '아직 YouTube 재생 신호가 없습니다. 먼저 영상을 재생해 주세요.'); return; }
      confirmedAV = true; text($('verification'), '영상·소리 직접 확인함'); log('사용자가 영상·소리 확인 버튼 선택'); refreshDiagnostics();
    }, 'primary');
    actions(confirm);
    actions(button('재생 확인 영상', function () {
      closeSheet(); queue = []; var demo = C.parse('https://www.youtube.com/watch?v=M7lc1UVf-VE'); demo.title = 'YouTube 공식 API 확인 영상'; startTrack(demo);
    }));
  }
  function external() {
    if (!current) { return; }
    var body = sheet('YouTube 페이지로 이동'); paragraph(body, '자두 화면을 나가 YouTube에서 엽니다. 돌아오면 재생 상태가 다시 준비될 수 있어요.');
    actions(button('취소', closeSheet)); actions(button('YouTube 열기', function () { window.location.href = current.url; }, 'primary'));
  }
  function beginEditing(input) { input.readOnly = false; input.setAttribute('data-editing', 'true'); focus(input); }
  function finishEditing(input) { input.readOnly = true; input.removeAttribute('data-editing'); }
  document.addEventListener('click', function (event) { if (event.target.tagName === 'INPUT' && event.target.hasAttribute('data-nav')) { beginEditing(event.target); } });
  document.addEventListener('focusout', function (event) { if (event.target.tagName === 'INPUT' && event.target.hasAttribute('data-nav')) { finishEditing(event.target); } });
  function navigable() {
    var scope = modal ? $('sheet') : document, list = scope.querySelectorAll('[data-nav]'), result = [], i, rect;
    for (i = 0; i < list.length; i += 1) {
      if (list[i].disabled || !list[i].offsetWidth || !list[i].offsetHeight || list[i].closest && list[i].closest('[hidden]')) { continue; }
      rect = list[i].getBoundingClientRect();
      result.push({ id: i, element: list[i], left: rect.left, right: rect.right, top: rect.top, bottom: rect.bottom });
    }
    return result;
  }
  function move(direction) {
    var list = navigable(), active = document.activeElement, from = null, chosen, i;
    for (i = 0; i < list.length; i += 1) { if (list[i].element === active) { from = list[i]; break; } }
    if (!from) { if (list.length) { focus(list[0].element); } return; }
    chosen = C.neighbour(list, from, direction);
    for (i = 0; i < list.length; i += 1) { if (list[i].id === chosen) { focus(list[i].element); break; } }
  }
  document.addEventListener('keydown', function (event) {
    var code = event.keyCode || event.which, active = document.activeElement, editing = active && active.getAttribute('data-editing') === 'true';
    lastKey = String(code); if (modal && $('diag-log')) { refreshDiagnostics(); }
    if (editing) {
      if (code === 13) { event.preventDefault(); finishEditing(active); if (active === $('query')) { focus($('open')); } else { focus($('sheet-actions').lastChild); } }
      else if (code === 461 || code === 27) { event.preventDefault(); finishEditing(active); focus(active === $('query') ? $('open') : $('sheet-actions').lastChild); }
      return;
    }
    if (code === 37 || code === 38 || code === 39 || code === 40) { event.preventDefault(); move({ 37: 'left', 38: 'up', 39: 'right', 40: 'down' }[code]); }
    else if (code === 13 && active && active.tagName === 'INPUT') { event.preventDefault(); beginEditing(active); }
    else if (code === 461 || code === 27) { if (modal) { event.preventDefault(); closeSheet(); } else { focus($('query')); } }
    else if (!modal && (code === 415 || code === 179)) { event.preventDefault(); if (playing && code === 179) { pause(); } else { play(); } }
    else if (!modal && code === 19) { event.preventDefault(); pause(); }
    else if (modal && code === 9) {
      var items = navigable(), first = items[0], last = items[items.length - 1];
      if (first && event.shiftKey && active === first.element) { event.preventDefault(); focus(last.element); }
      else if (last && !event.shiftKey && active === last.element) { event.preventDefault(); focus(first.element); }
    }
  });
  $('address-form').addEventListener('submit', submitQuery);
  $('sheet-close').addEventListener('click', closeSheet);
  $('help').addEventListener('click', showHelp); $('diagnostics').addEventListener('click', showDiagnostics);
  $('show-all').addEventListener('click', function () { filterTerm = ''; $('query').value = ''; renderList(); status('저장 목록 전체를 표시했어요.'); });
  $('save').addEventListener('click', saveTrack); $('play').addEventListener('click', play); $('pause').addEventListener('click', pause);
  $('previous').addEventListener('click', function () { nextTrack(-1); }); $('next').addEventListener('click', function () { nextTrack(1); });
  $('probe').addEventListener('click', function () { var track = C.parse('https://www.youtube.com/watch?v=M7lc1UVf-VE'); track.title = 'YouTube 공식 API 확인 영상'; queue = []; startTrack(track); });
  $('retry').addEventListener('click', function () { if (current) { startTrack(current); } });
  $('external').addEventListener('click', external);
  $('video-focus').addEventListener('click', function () { if (frame) { frame.focus(); status('YouTube 화면 조작 중입니다. 돌아오려면 뒤로 키 또는 매직 리모컨 포인터를 사용해 주세요.'); } });
  $('pet-call').addEventListener('click', function () {
    text($('pet-message'), playing ? '야옹. 나도 듣고 있어.' : '야옹. 여기 있어.');
    try { var sound = new Audio('assets/pet/Sounds/meow.wav'); sound.volume = 0.3; var promise = sound.play(); if (promise && promise.catch) { promise.catch(function () { status('자두 소리를 재생하지 못했어요.'); }); } } catch (error) { status('자두 소리를 재생하지 못했어요.'); }
  });
  document.addEventListener('visibilitychange', function () { log(document.hidden ? '페이지 숨김 (계속 재생은 보장하지 않음)' : '페이지 다시 보임'); petAnimation(); });
  window.onYouTubeIframeAPIReady = function () { apiReady = true; clearTimeout(apiTimer); log('YouTube IFrame API 응답'); connectAPI(); };
  function loadAPI() {
    if (window.YT && window.YT.Player) { window.onYouTubeIframeAPIReady(); return; }
    var script = document.createElement('script'); script.src = 'https://www.youtube.com/iframe_api'; script.async = true;
    script.onerror = function () { lastError = 'YouTube API 불러오기 실패'; log(lastError); status('YouTube 연결 파일을 불러오지 못했어요. TV 인터넷 연결과 브라우저 지원을 확인해 주세요.'); };
    document.head.appendChild(script);
    apiTimer = setTimeout(function () { if (!apiReady) { log('YouTube API 15초 응답 없음'); status('YouTube 연결 응답이 없어요. ‘TV 확인’에서 상태를 확인해 주세요.'); } }, 15000);
  }
  readStorage(); renderList(); controls(); petAnimation(); log('TV 화면 준비'); focus($('probe')); loadAPI();
}());

